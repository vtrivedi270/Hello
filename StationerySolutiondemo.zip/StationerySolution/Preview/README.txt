STATIONERY HUB - CLICKABLE PREVIEW (dummy data)

Open stationery-preview.html by double-clicking it (Chrome, Edge, Firefox, Safari). No install, no server, no login.

How to present:
 1. Use the "View as" dropdown (top right) to switch role: Requestor, Reporting Manager, Dept Head, Div Head, HRAD, Admin.
 2. Suggested demo path:
    Requestor: New request -> add items -> Submit (or open the existing draft and Edit / Submit)
    Reporting Manager / Dept Head / Div Head: Requests > Pending for me -> Approve / Ask to amend / Reject
    HRAD: process the request (approved qty, issue from store, vendor) -> Preview PDF -> Mark delivered
    Requestor: verify received items -> Close or Partial close
    HRAD: re-order the shortfall, Store stock (add / adjust / history), Edit line items
    Admin: Master data (add, edit, delete, import from Excel), E-mail log
 3. Delegation: as Reporting Manager delegate to a person, then switch "View as" to that person.
 4. Excel import: Admin > Master data > Import from Excel, or New request > Import from Excel.
    Use the "sample" buttons (work offline). Uploading your own .xlsx needs internet once (it loads the SheetJS library).

Everything is dummy data held in the page; refreshing the page resets it. Nothing is sent anywhere.
