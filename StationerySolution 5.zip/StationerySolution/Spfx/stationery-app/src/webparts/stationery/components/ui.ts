import * as React from 'react';
export const C = { pri: '#4338ca', pri2: '#6366f1', bg: '#f3f4f8', card: '#ffffff', ink: '#1f2433', mut: '#5b6275', line: '#e3e6ee', side: '#1e1b4b' };
export const card: React.CSSProperties = { background: C.card, border: '1px solid ' + C.line, borderRadius: 14, padding: 18, boxShadow: '0 1px 2px rgba(20,20,60,.05)' };
export const row = (gap: number = 12): React.CSSProperties => ({ display: 'flex', gap: gap, flexWrap: 'wrap', alignItems: 'center' });
export const h1: React.CSSProperties = { fontSize: 22, fontWeight: 700, margin: 0, color: C.ink };
export const h2: React.CSSProperties = { fontSize: 15, fontWeight: 600, margin: '0 0 12px', color: C.ink };
export const mut: React.CSSProperties = { color: C.mut, fontSize: 12 };
export const th: React.CSSProperties = { textAlign: 'left', fontSize: 12, color: C.mut, fontWeight: 600, padding: '10px 10px', borderBottom: '1px solid ' + C.line, whiteSpace: 'nowrap' };
export const td: React.CSSProperties = { padding: '11px 10px', borderBottom: '1px solid ' + C.line, whiteSpace: 'nowrap', color: C.ink };
export const fmt = (n: number): string => '\u20B9' + (n || 0).toLocaleString('en-IN');
export const fmtDate = (d: string): string => new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
export const STATUS: { [k: string]: [string, string] } = {
  Draft: ['Draft', '#6b7280'], InReview: ['In review', '#2563eb'], AmendRequired: ['Amend required', '#c2410c'],
  Rejected: ['Rejected', '#dc2626'], HRApproval: ['HR approval', '#7c3aed'], Ordered: ['Ordered', '#0f766e'],
  Delivered: ['Delivered', '#4f46e5'], Cancelled: ['Cancelled', '#6b7280'], Closed: ['Closed', '#15803d'], PartialClosed: ['Partial closed', '#b45309']
};
export const STAGE: { [k: string]: string } = { ReportingManager: 'Reporting Manager', DeptHead: 'Dept Head', DivHead: 'Division Head', HRAD: 'HRAD', Requestor: 'Requestor' };
