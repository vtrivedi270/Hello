declare interface IStationeryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  ApiBaseUrlFieldLabel: string;
  ApiResourceFieldLabel: string;
  ScreenPercentFieldLabel: string;
}
declare module 'StationeryWebPartStrings' {
  const strings: IStationeryWebPartStrings;
  export = strings;
}
