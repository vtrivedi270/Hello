/* Run on a database that already has Upgrade_001 (or the second version of StationeryDB.sql).
   Adds: approver delegation, e-mail retry columns. */
USE StationeryDB;
GO
IF OBJECT_ID('ApproverDelegation') IS NULL
BEGIN
  CREATE TABLE ApproverDelegation (
    DelegationId INT IDENTITY PRIMARY KEY,
    FromEmployeeId INT NOT NULL REFERENCES EmployeeMaster(EmployeeId),
    ToEmployeeId INT NOT NULL REFERENCES EmployeeMaster(EmployeeId),
    StartDate DATE NOT NULL, EndDate DATE NOT NULL, Reason NVARCHAR(300) NULL,
    IsActive BIT NOT NULL DEFAULT 1, CreatedBy NVARCHAR(256) NULL, CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Deleg CHECK (EndDate >= StartDate AND FromEmployeeId <> ToEmployeeId));
  CREATE INDEX IX_Deleg_To ON ApproverDelegation(ToEmployeeId, IsActive, StartDate, EndDate);
  CREATE INDEX IX_Deleg_From ON ApproverDelegation(FromEmployeeId, IsActive, StartDate, EndDate);
END
IF COL_LENGTH('EmailLog','AttachPo') IS NULL ALTER TABLE EmailLog ADD AttachPo BIT NOT NULL CONSTRAINT DF_Email_Att DEFAULT 0;
IF COL_LENGTH('EmailLog','LastAttemptAt') IS NULL ALTER TABLE EmailLog ADD LastAttemptAt DATETIME2 NULL;
GO
ALTER VIEW dbo.vw_EmployeeRoles AS
SELECT EmployeeId, Email, 'Requestor' AS RoleName FROM EmployeeMaster WHERE IsActive=1
UNION SELECT EmployeeId, Email, Role FROM EmployeeMaster WHERE IsActive=1 AND Role IN ('HRAD','Admin')
UNION SELECT e.EmployeeId, e.Email, 'Approver' FROM EmployeeMaster e
 WHERE e.IsActive=1 AND (e.Role IN ('ReportingManager','DeptHead','DivHead')
   OR EXISTS (SELECT 1 FROM EmployeeMaster x WHERE x.ReportingManagerId=e.EmployeeId AND x.IsActive=1)
   OR EXISTS (SELECT 1 FROM DepartmentMaster d WHERE d.DepartmentHeadId=e.EmployeeId)
   OR EXISTS (SELECT 1 FROM DivisionMaster v WHERE v.DivisionHeadId=e.EmployeeId)
   OR EXISTS (SELECT 1 FROM ApproverDelegation g WHERE g.ToEmployeeId=e.EmployeeId AND g.IsActive=1 AND g.EndDate>=CAST(GETDATE() AS DATE)));
GO
