import * as React from 'react';

/** Small UI kit: React versions of the preview's building blocks (same class names as the preview stylesheet). */
const IC: { [k: string]: string } = {
  dash: '<path d="M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  add: '<path d="M12 5v14M5 12h14"/>',
  adm: '<circle cx="12" cy="12" r="3"/><path d="M19 12l2-1.5-2-3.4-2.3.9-2-1.2L14 3h-4l-.4 2.8-2 1.2-2.3-.9-2 3.4L5 12l-2 1.5 2 3.4 2.3-.9 2 1.2L10 21h4l.4-2.8 2-1.2 2.3.9 2-3.4z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  box: '<path d="M21 8l-9-5-9 5v8l9 5 9-5zM3 8l9 5 9-5M12 13v8"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  mail: '<path d="M4 4h16v16H4zM4 6l8 7 8-7"/>',
  pen: '<path d="M4 20l4-1 11-11-3-3L5 16zM14 6l3 3"/>'
};
export const Icon: React.FC<{ k: string; style?: React.CSSProperties }> = ({ k, style }) =>
  <svg className="ic" viewBox="0 0 24 24" aria-hidden="true" style={style} dangerouslySetInnerHTML={{ __html: IC[k] }} />;

/** Toast (same look as the preview). Appended inside .sh-root so the scoped CSS applies. */
export const toast = (msg: string): void => {
  const root = document.querySelector('.sh-root');
  if (!root) return;
  const e = document.createElement('div');
  e.className = 'toast'; e.setAttribute('role', 'status'); e.textContent = msg;
  root.appendChild(e);
  window.setTimeout(() => { if (e.parentNode) e.parentNode.removeChild(e); }, 2800);
};

export const Chip: React.FC<{ bg: string }> = ({ bg, children }) => <span className="chip" style={{ background: bg }}>{children}</span>;

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { v?: 'g' | 'd'; s?: boolean };
export const Btn: React.FC<BtnProps> = ({ v, s, className, children, ...rest }) =>
  <button type="button" className={'btn' + (v ? ' ' + v : '') + (s ? ' s' : '') + (className ? ' ' + className : '')} {...rest}>{children}</button>;

/** Error / info bar (.warn / .note in the preview). */
export const Alert: React.FC<{ kind?: 'error' | 'info' | 'ok'; onClose?: () => void; style?: React.CSSProperties }> = ({ kind, onClose, style, children }) => (
  <div className={kind === 'error' ? 'warn' : 'note'} role={kind === 'error' ? 'alert' : 'status'}
    style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', ...style }}>
    <div>{children}</div>
    {onClose && <button type="button" className="btn g s" onClick={onClose} aria-label="Dismiss">{'\u2715'}</button>}
  </div>);

export const Modal: React.FC<{ onClose: () => void; wide?: boolean }> = ({ onClose, wide, children }) => (
  <div className="ov" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="mo" role="dialog" aria-modal="true" style={wide ? { width: 'min(860px,100%)' } : undefined}>{children}</div>
  </div>);

export const Tabs: React.FC<{ items: [string, string][]; sel: string; onSel: (k: string) => void }> = ({ items, sel, onSel }) => (
  <div className="tabs">{items.map(t => <button type="button" key={t[0]} className={'tab' + (sel === t[0] ? ' on' : '')} onClick={() => onSel(t[0])}>{t[1]}</button>)}</div>);

export const Field: React.FC<{ label: string; style?: React.CSSProperties }> = ({ label, style, children }) =>
  <div className="fld" style={style}><span className="lab">{label}</span>{children}</div>;

/** Pager exactly like the preview: Prev, "Page x of y · n record(s)", Next, rows per page. */
export const Pager: React.FC<{ page: number; total: number; pageSize: number; onPage: (p: number) => void; onSize?: (n: number) => void }> =
({ page, total, pageSize, onPage, onSize }) => {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const p = Math.min(page, pages);
  return (
    <div className="row" style={{ marginTop: 12 }}>
      <button type="button" className="btn g s" disabled={p <= 1} onClick={() => onPage(p - 1)}>Prev</button>
      <span>Page {p} of {pages} {'\u00B7'} {total} record(s)</span>
      <button type="button" className="btn g s" disabled={p >= pages} onClick={() => onPage(p + 1)}>Next</button>
      {onSize && <label className="mut">Rows <select aria-label="Rows per page" value={pageSize} onChange={e => onSize(Number(e.target.value))}>
        {[5, 10, 20, 50].map(n => <option key={n} value={n}>{n}</option>)}</select></label>}
    </div>);
};

export function usePaged<T>(rows: T[], size: number, page: number): T[] { return rows.slice((page - 1) * size, page * size); }
