import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Me, Route, RouteName } from '../models';
import { Alert } from './kit';
import SideNav from './SideNav';
import Dashboard from './Dashboard';
import RequestList from './RequestList';
import RequestForm from './RequestForm';
import RequestDetailView from './RequestDetailView';
import Admin from './Admin';
import Stock from './Stock';
import Delegation from './Delegation';
import EmailLog from './EmailLog';

interface Props { api: ApiService; }
interface DevUser { employeeId: number; fullName: string; email: string; persona: string; }
const PERSONAS = ['Requestor', 'Reporting Manager', 'Dept Head', 'Division Head', 'HRAD', 'Admin'];

const App: React.FC<Props> = ({ api }) => {
  const [me, setMe] = useState<Me>();
  const [err, setErr] = useState<string>();
  const [route, setRoute] = useState<Route>({ name: 'dash' });
  const [pending, setPending] = useState(0);
  const [collapsed, setCollapsed] = useState(typeof window !== 'undefined' && window.innerWidth < 900);
  const [devUsers, setDevUsers] = useState<DevUser[]>([]);

  const loadMe = (): Promise<void> => api.get<Me>('me').then(setMe).catch((e: Error) => setErr(e.message));
  useEffect(() => {
    loadMe().then(() => { if (api.devMode) api.devUsers().then(setDevUsers).catch(() => undefined); });
  }, []);
  useEffect(() => { if (me) api.get<{ total: number }>('requests?view=pending&page=1&pageSize=1').then(r => setPending(r.total)).catch(() => undefined); }, [me, route.name, route.id]);

  const go = (name: RouteName, id?: number): void => { setRoute({ name: name, id: id }); window.scrollTo(0, 0); };

  /** "View as": dev mode only. Signs in again as the chosen person, so the API really applies that person's roles. */
  const viewAs = async (email: string): Promise<void> => {
    try { await api.switchUser(email); setMe(undefined); await loadMe(); setRoute({ name: 'dash' }); }
    catch (e) { setErr((e as Error).message); }
  };

  const shell = (children: React.ReactNode): JSX.Element => <div className="sh-root">{children}</div>;
  if (err && !me) return shell(<div className="page"><Alert kind="error">Cannot load your profile: {err}</Alert></div>);
  if (!me) return shell(<div className="page"><span className="mut">Loading Stationery Hub...</span></div>);

  const has = (r: string): boolean => me.roles.indexOf(r) > -1;
  const active: RouteName = route.name === 'detail' || route.name === 'edit' ? 'list' : route.name;
  const blocked = (m: string): JSX.Element => <Alert kind="error">{m}</Alert>;
  let view: React.ReactNode;
  switch (route.name) {
    case 'list': view = <RequestList api={api} me={me} go={go} />; break;
    case 'new': view = <RequestForm api={api} me={me} go={go} />; break;
    case 'edit': view = <RequestForm api={api} me={me} go={go} requestId={route.id} />; break;
    case 'detail': view = <RequestDetailView api={api} me={me} go={go} requestId={route.id!} />; break;
    case 'stock': view = has('HRAD') || has('Admin') ? <Stock api={api} /> : blocked('HRAD or Admin access required'); break;
    case 'delegation': view = <Delegation api={api} me={me} />; break;
    case 'emails': view = has('Admin') ? <EmailLog api={api} /> : blocked('Admin access required'); break;
    case 'admin': view = has('Admin') ? <Admin api={api} /> : blocked('Admin access required'); break;
    default: view = <Dashboard api={api} me={me} go={go} />;
  }

  const options = devUsers.slice().sort((a, b) => PERSONAS.indexOf(a.persona) - PERSONAS.indexOf(b.persona) || a.fullName.localeCompare(b.fullName));
  return shell(
    <div className="shell">
      <SideNav me={me} active={active} pending={pending} collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} go={go} />
      <div className="main">
        <header className="top">
          <div className="crumb">SharePoint {'\u203A'} Stationery {'\u203A'} {route.name === 'new' ? 'new' : route.name}</div>
          <div className="who">
            {api.devMode && options.length > 0 ? (<>
              <label className="mut" htmlFor="sh-viewas">View as</label>
              <select id="sh-viewas" value={me.email.toLowerCase()} onChange={e => viewAs(e.target.value)}>
                {PERSONAS.map(p => options.some(o => o.persona === p) && (
                  <optgroup key={p} label={p}>{options.filter(o => o.persona === p).map(o => <option key={o.employeeId} value={o.email.toLowerCase()}>{p} {'\u00B7'} {o.fullName}</option>)}</optgroup>))}
              </select></>)
              : <span className="mut">{me.fullName} {'\u00B7'} {me.persona}</span>}
          </div>
        </header>
        <main className="page">{err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}{view}</main>
      </div>
    </div>);
};
export default App;
