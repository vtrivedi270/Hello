/** Shared helpers (formatting, status colours, CSV). Visual styling lives in styles/shStyles.ts (generated from the preview). */
export const fmt = (n: number): string => '\u20B9' + (n || 0).toLocaleString('en-IN');
export const fmtDate = (d: string): string => new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
export const STATUS: { [k: string]: [string, string] } = {
  Draft: ['Draft', '#6b7280'], InReview: ['In review', '#2563eb'], AmendRequired: ['Amend required', '#c2410c'], Rejected: ['Rejected', '#dc2626'],
  HRApproval: ['HR approval', '#7c3aed'], Ordered: ['Ordered', '#0f766e'], Delivered: ['Delivered', '#1d4ed8'], Closed: ['Closed', '#15803d'],
  PartialClosed: ['Partial closed', '#b45309'], Cancelled: ['Cancelled', '#6b7280']
};
export const STAGE: { [k: string]: string } = { ReportingManager: 'Reporting Manager', DeptHead: 'Dept Head', DivHead: 'Division Head', HRAD: 'HRAD', Requestor: 'Requestor' };
export const csvCell = (v: any): string => '"' + String(v === undefined || v === null ? '' : v).replace(/"/g, '""') + '"';
export const downloadText = (name: string, text: string): void => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\uFEFF' + text], { type: 'text/csv;charset=utf-8' })); a.download = name;
  document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(a.href);
};
export const hasRole = (roles: string[], r: string): boolean => roles.indexOf(r) > -1;
