import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Item, RequestDetail, Vendor } from '../models';
import { Btn, Field, Modal } from './kit';

interface Props { api: ApiService; r: RequestDetail; onChanged: (msg: string) => void; onError: (msg: string) => void; }
interface Line { itemId: number; itemName: string; quantity: number; minQty: number; fixed: boolean; old: boolean; }

/** HRAD tools: edit line items on any open request, re-order a shortfall or close with shortfall (partial close). */
const HradTools: React.FC<Props> = ({ api, r, onChanged, onError }) => {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [lines, setLines] = useState<Line[]>([]);
  const [reason, setReason] = useState('');
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [vendorId, setVendorId] = useState(0);
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get<Item[]>('masters/items?active=true').then(setItems).catch(() => undefined);
    api.get<Vendor[]>('masters/vendors?active=true').then(v => { setVendors(v); if (v.length) setVendorId(v[0].vendorId); }).catch(() => undefined);
  }, []);

  const terminal = ['Closed', 'Rejected', 'Cancelled'].indexOf(r.status) > -1;
  const partial = r.status === 'PartialClosed';
  const post = r.status === 'Ordered' || r.status === 'Delivered';
  if (terminal) return null;

  const run = async (fn: () => Promise<any>, msg: string): Promise<void> => {
    setBusy(true);
    try { await fn(); setOpen(false); setComment(''); onChanged(msg); } catch (e) { onError((e as Error).message); }
    setBusy(false);
  };
  const startEdit = (): void => {
    setLines(r.items.map(i => ({ itemId: i.itemId, itemName: i.itemName, quantity: i.quantity, minQty: Math.max(i.issuedFromStockQty, i.receivedQty), fixed: i.issuedFromStockQty > 0 || i.receivedQty > 0, old: true })));
    setReason(''); setOpen(true);
  };
  const upd = (idx: number, patch: Partial<Line>): void => setLines(lines.map((l, i) => i === idx ? { ...l, ...patch } : l));
  const pick = (idx: number, itemId: number): void => {
    if (lines.some((l, i) => i !== idx && l.itemId === itemId)) { onError('Item already in the request'); return; }
    const it = items.filter(x => x.itemId === itemId)[0];
    upd(idx, { itemId: itemId, itemName: it ? it.itemName : '' });
  };
  const save = (): void => {
    if (!reason.trim()) { onError('Reason is required'); return; }
    if (lines.length === 0) { onError('A request needs at least one item'); return; }
    if (lines.some(l => !l.itemId || !(l.quantity > 0) || l.quantity < l.minQty)) { onError('Check items and quantities (not below issued / received quantity)'); return; }
    run(() => api.put<any>('hrad/' + r.requestId + '/items', { reason: reason, items: lines.map(l => ({ itemId: l.itemId, quantity: l.quantity })) }),
      post ? 'Items updated. Please resend the PO to the vendor.' : 'Line items updated');
  };

  const outstanding = r.items.map(i => ({ i: i, exp: i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty })).map(x => ({ ...x, out: x.exp - x.i.receivedQty })).filter(x => x.out > 0);

  return (<>
    {partial && (<div className="card">
      <h2>Shortfall</h2>
      <div className="tw"><table><thead><tr><th>Item</th><th>Expected</th><th>Received</th><th>Outstanding</th></tr></thead>
        <tbody>{outstanding.map(x => <tr key={x.i.requestItemId}><td>{x.i.itemName}</td><td>{x.exp}</td><td>{x.i.receivedQty}</td><td><b>{x.out}</b></td></tr>)}</tbody></table></div>
      <div className="row" style={{ marginTop: 12 }}>
        <Field label="Vendor for re-order"><select value={vendorId} onChange={e => setVendorId(Number(e.target.value))}>{vendors.map(v => <option key={v.vendorId} value={v.vendorId}>{v.vendorName}</option>)}</select></Field>
        <Field label="Comment (required to close with shortfall)"><input value={comment} onChange={e => setComment(e.target.value)} /></Field>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <Btn disabled={busy || !vendorId} onClick={() => run(() => api.post('hrad/' + r.requestId + '/reorder', { vendorId: vendorId, comments: comment }), 'Outstanding quantity re-ordered')}>Re-order shortfall</Btn>
        <Btn v="g" disabled={busy || !comment.trim()} onClick={() => run(() => api.post('hrad/' + r.requestId + '/close-short', { action: 'CloseShort', comments: comment }), 'Request closed with shortfall')}>Close with shortfall</Btn>
      </div></div>)}

    {!partial && (<div className="card">
      <h2>HRAD tools</h2>
      <Btn v="g" onClick={startEdit}>Edit line items</Btn>
      {post && <div className="mut" style={{ marginTop: 8 }}>The vendor order was already sent. After changing items, use Resend PO.</div>}
    </div>)}

    {open && (
      <Modal onClose={() => setOpen(false)}>
        <h2>Edit line items {'\u00B7'} {r.requestNo}</h2>
        {post && <div className="warn" style={{ marginBottom: 10 }}>The order was already sent to the vendor. Resend the PO after saving.</div>}
        <table><thead><tr><th>Item</th><th>Qty</th><th /></tr></thead>
          <tbody>{lines.map((l, x) => (
            <tr key={x}>
              <td>{l.old ? l.itemName : <select value={l.itemId} onChange={e => pick(x, Number(e.target.value))}><option value={0}>Select item</option>
                {items.map(o => <option key={o.itemId} value={o.itemId}>{o.itemCode} {'\u2013'} {o.itemName}</option>)}</select>}</td>
              <td><input type="number" min={0.01} step={0.01} value={l.quantity} style={{ width: 90 }} onChange={e => upd(x, { quantity: Math.max(0, Number(e.target.value) || 0) })} /></td>
              <td><Btn v="g" s disabled={l.fixed} title={l.fixed ? 'Already issued / received' : ''} onClick={() => setLines(lines.filter((_, i) => i !== x))}>Remove</Btn></td>
            </tr>))}</tbody></table>
        <div style={{ marginTop: 10 }}><Btn v="g" s onClick={() => setLines([...lines, { itemId: 0, itemName: '', quantity: 1, minQty: 0, fixed: false, old: false }])}>+ Add item</Btn></div>
        <Field label="Reason for change (required)" style={{ marginTop: 12 }}><textarea rows={2} value={reason} onChange={e => setReason(e.target.value)} /></Field>
        <div className="row" style={{ marginTop: 12 }}><Btn disabled={busy} onClick={save}>Save changes</Btn><Btn v="g" onClick={() => setOpen(false)}>Cancel</Btn></div>
      </Modal>)}
  </>);
};
export default HradTools;
