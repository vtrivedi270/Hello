import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Alert, Btn, Field, Modal, Pager, Tabs, toast } from './kit';
import ExcelImportPanel from './ExcelImportPanel';

interface FieldDef { key: string; label: string; type?: 'text' | 'number' | 'select'; req?: boolean; from?: string; idKey?: string; labelKey?: string; options?: string[]; optional?: boolean; }
interface Cfg { title: string; one: string; idKey: string; fields: FieldDef[]; }

const ROLES = ['Requestor', 'ReportingManager', 'DeptHead', 'DivHead', 'HRAD', 'Admin'];
const EMP = { from: 'employees', idKey: 'employeeId', labelKey: 'fullName' };
const CFG: { [k: string]: Cfg } = {
  items: { title: 'Items', one: 'item', idKey: 'itemId', fields: [
    { key: 'itemCode', label: 'Code', req: true }, { key: 'itemName', label: 'Name', req: true },
    { key: 'categoryId', label: 'Category', type: 'select', from: 'categories', idKey: 'categoryId', labelKey: 'categoryName', optional: true },
    { key: 'unit', label: 'Unit', req: true }, { key: 'rate', label: 'Rate', type: 'number' },
    { key: 'stockQty', label: 'Stock', type: 'number' }, { key: 'reorderLevel', label: 'Reorder level', type: 'number' }] },
  categories: { title: 'Categories', one: 'category', idKey: 'categoryId', fields: [{ key: 'categoryName', label: 'Category name', req: true }] },
  vendors: { title: 'Vendors', one: 'vendor', idKey: 'vendorId', fields: [
    { key: 'vendorName', label: 'Vendor name', req: true }, { key: 'contactPerson', label: 'Contact' }, { key: 'email', label: 'Email', req: true },
    { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address' }, { key: 'gstNo', label: 'GST no' }] },
  divisions: { title: 'Divisions', one: 'division', idKey: 'divisionId', fields: [
    { key: 'divisionName', label: 'Division name', req: true }, { key: 'divisionHeadId', label: 'Division head', type: 'select', ...EMP, optional: true }] },
  departments: { title: 'Departments', one: 'department', idKey: 'departmentId', fields: [
    { key: 'departmentName', label: 'Name', req: true },
    { key: 'divisionId', label: 'Division', type: 'select', from: 'divisions', idKey: 'divisionId', labelKey: 'divisionName', req: true },
    { key: 'departmentHeadId', label: 'Head', type: 'select', ...EMP, optional: true }] },
  employees: { title: 'Employees', one: 'employee', idKey: 'employeeId', fields: [
    { key: 'employeeCode', label: 'Code', req: true }, { key: 'fullName', label: 'Full name', req: true }, { key: 'email', label: 'Email', req: true },
    { key: 'departmentId', label: 'Department', type: 'select', from: 'departments', idKey: 'departmentId', labelKey: 'departmentName', req: true },
    { key: 'divisionId', label: 'Division', type: 'select', from: 'divisions', idKey: 'divisionId', labelKey: 'divisionName', req: true },
    { key: 'reportingManagerId', label: 'Reporting manager', type: 'select', ...EMP, optional: true },
    { key: 'role', label: 'Role', type: 'select', options: ROLES, req: true }] }
};
const LOOKUPS = ['employees', 'divisions', 'departments', 'categories'];

/** Master data with complete CRUD: search, add, edit, activate / deactivate, delete (the API blocks delete when in use), import / export Excel. */
const Admin: React.FC<{ api: ApiService }> = ({ api }) => {
  const [tab, setTab] = useState('items');
  const [rows, setRows] = useState<any[]>([]);
  const [lk, setLk] = useState<{ [k: string]: any[] }>({});
  const [edit, setEdit] = useState<any>();
  const [q, setQ] = useState('');
  const [inactive, setInactive] = useState(true);
  const [err, setErr] = useState<string>();
  const [mErr, setMErr] = useState<string>();
  const [importOpen, setImportOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(5);
  const cfg = CFG[tab];

  const loadLookups = (): void => { LOOKUPS.forEach(k => api.get<any[]>('masters/' + k).then(d => setLk(p => ({ ...p, [k]: d }))).catch(() => undefined)); };
  const load = (): void => { api.get<any[]>('masters/' + tab).then(setRows).catch((e: Error) => setErr(e.message)); };
  useEffect(() => { loadLookups(); }, []);
  useEffect(() => { setEdit(undefined); setQ(''); setPage(1); load(); }, [tab]);

  const label = (f: FieldDef, v: any): string => {
    if (v === null || v === undefined || v === '') return '\u2013';
    if (f.type !== 'select' || !f.from) return String(v);
    const hit = (lk[f.from] || []).filter(x => x[f.idKey!] === v)[0];
    return hit ? hit[f.labelKey!] : String(v);
  };
  const save = async (): Promise<void> => {
    const miss = cfg.fields.filter(f => f.req && (edit[f.key] === undefined || edit[f.key] === '' || edit[f.key] === null || edit[f.key] === 0))[0];
    if (miss) { setMErr(miss.label + ' is required'); return; }
    try {
      if (edit[cfg.idKey]) await api.put('masters/' + tab + '/' + edit[cfg.idKey], edit); else await api.post('masters/' + tab, edit);
      toast(cfg.one + ' saved'); setEdit(undefined); setMErr(undefined); load(); loadLookups();
    } catch (e) { setMErr((e as Error).message); }
  };
  const toggle = async (r: any): Promise<void> => { try { await api.put('masters/' + tab + '/' + r[cfg.idKey], { ...r, isActive: !r.isActive }); load(); loadLookups(); } catch (e) { setErr((e as Error).message); } };
  const remove = async (r: any): Promise<void> => {
    if (!window.confirm('Delete this ' + cfg.one + ' permanently? If it is already used, deactivate it instead.')) return;
    try { await api.del('masters/' + tab + '/' + r[cfg.idKey]); toast(cfg.one + ' deleted'); load(); loadLookups(); } catch (e) { setErr((e as Error).message); }
  };
  const exportExcel = (): void => { api.download('import/' + tab + '/export', tab + '-export.xlsx').then(() => toast('Exported ' + rows.length + ' ' + cfg.title.toLowerCase())).catch((e: Error) => setErr(e.message)); };

  const filtered = rows.filter(r => (inactive || r.isActive) && (!q || cfg.fields.some(f => label(f, r[f.key]).toLowerCase().indexOf(q.toLowerCase()) > -1)));
  const shown = filtered.slice((page - 1) * size, page * size);

  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <h1>Master data</h1>
      <div className="row" style={{ gap: 8 }}>
        <Btn v="g" onClick={() => { setErr(undefined); setImportOpen(true); }}>Import from Excel</Btn>
        <Btn v="g" onClick={exportExcel}>Export</Btn>
        <Btn onClick={() => { setMErr(undefined); setEdit({ isActive: true, ...(tab === 'employees' ? { role: 'Requestor' } : {}) }); }}>+ Add {cfg.one}</Btn>
      </div>
    </div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <Tabs sel={tab} onSel={setTab} items={Object.keys(CFG).map(k => [k, CFG[k].title] as [string, string])} />
      <div className="row" style={{ margin: '12px 0' }}>
        <input placeholder={'Search ' + cfg.title.toLowerCase()} aria-label="Search" value={q} onChange={e => { setQ(e.target.value); setPage(1); }} />
        <label className="mut"><input type="checkbox" checked={inactive} onChange={e => { setInactive(e.target.checked); setPage(1); }} /> Show inactive</label>
        <span className="mut">{filtered.length} of {rows.length}</span>
      </div>
      <div className="tw"><table>
        <thead><tr>{cfg.fields.map(f => <th key={f.key}>{f.label}</th>)}<th>Active</th><th /></tr></thead>
        <tbody>
          {shown.length === 0 && <tr><td colSpan={cfg.fields.length + 2} className="mut">No records.</td></tr>}
          {shown.map(r => (
            <tr key={r[cfg.idKey]} style={{ opacity: r.isActive ? 1 : 0.5 }}>
              {cfg.fields.map(f => <td key={f.key}>{label(f, r[f.key])}</td>)}
              <td><input type="checkbox" aria-label="Active" checked={r.isActive} onChange={() => toggle(r)} /></td>
              <td><div className="row" style={{ gap: 6 }}><Btn v="g" s onClick={() => { setMErr(undefined); setEdit({ ...r }); }}>Edit</Btn><Btn v="g" s style={{ color: 'var(--bad)' }} onClick={() => remove(r)}>Delete</Btn></div></td>
            </tr>))}
        </tbody></table></div>
      <Pager page={page} total={filtered.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>

    {edit && (
      <Modal onClose={() => setEdit(undefined)}>
        <h2>{edit[cfg.idKey] ? 'Edit ' : 'Add '}{cfg.one}</h2>
        {mErr && <Alert kind="error" style={{ marginBottom: 10 }}>{mErr}</Alert>}
        {cfg.fields.map(f => (
          <Field key={f.key} label={f.label + (f.req ? ' *' : '')} style={{ marginBottom: 10 }}>
            {f.type === 'select' ? (
              <select value={edit[f.key] === null || edit[f.key] === undefined ? (f.options ? '' : 0) : edit[f.key]}
                onChange={e => setEdit({ ...edit, [f.key]: f.options ? e.target.value : (Number(e.target.value) || null) })}>
                {f.options ? f.options.map(o => <option key={o} value={o}>{o}</option>)
                  : [<option key="n" value={0}>{f.optional ? '(none)' : 'Select'}</option>].concat((lk[f.from!] || []).filter(x => x.isActive !== false).map(x => <option key={x[f.idKey!]} value={x[f.idKey!]}>{x[f.labelKey!]}</option>))}
              </select>
            ) : (
              <input type={f.type === 'number' ? 'number' : 'text'} value={edit[f.key] === null || edit[f.key] === undefined ? '' : edit[f.key]}
                onChange={e => setEdit({ ...edit, [f.key]: f.type === 'number' ? Number(e.target.value) || 0 : e.target.value })} />)}
          </Field>))}
        <label><input type="checkbox" checked={!!edit.isActive} onChange={e => setEdit({ ...edit, isActive: e.target.checked })} /> Active</label>
        <div className="row" style={{ marginTop: 14 }}><Btn onClick={save}>Save</Btn><Btn v="g" onClick={() => setEdit(undefined)}>Cancel</Btn></div>
      </Modal>)}
    {importOpen && <ExcelImportPanel api={api} entity={tab} onClose={() => setImportOpen(false)} onImported={m => { toast(m); load(); loadLookups(); }} />}
  </>);
};
export default Admin;
