import * as React from 'react';
import { useState } from 'react';
import { ApiService } from '../services/ApiService';
import { ImportReport } from '../models';
import { Alert, Btn, Chip, Modal, Pager, Tabs } from './kit';
import { csvCell, downloadText } from './ui';

const SPECS: { [k: string]: { title: string; req: string[]; opt: string[]; rules: string } } = {
  items: { title: 'Items', req: ['ItemCode', 'ItemName', 'Unit', 'Rate'], opt: ['Category', 'StockQty', 'ReorderLevel', 'Active'],
    rules: 'ItemCode unique (max 30) \u00B7 Rate 0 or more, max 2 decimals \u00B7 Category must already exist \u00B7 StockQty is used for new items only (existing stock changes via Store stock)' },
  categories: { title: 'Categories', req: ['CategoryName'], opt: ['Active'], rules: 'CategoryName unique (max 100) \u00B7 Active = Y or N' },
  vendors: { title: 'Vendors', req: ['VendorName', 'Email'], opt: ['ContactPerson', 'Phone', 'Address', 'GSTNo', 'Active'], rules: 'Valid e-mail \u00B7 GSTNo = 15 letters / digits \u00B7 VendorName unique' },
  divisions: { title: 'Divisions', req: ['DivisionName'], opt: ['DivisionHead', 'Active'], rules: 'DivisionName unique \u00B7 DivisionHead = code, e-mail or name of an existing employee' },
  departments: { title: 'Departments', req: ['DepartmentName', 'Division'], opt: ['DepartmentHead', 'Active'], rules: 'Division must already exist \u00B7 name + division unique \u00B7 DepartmentHead = code, e-mail or name of an existing employee' },
  employees: { title: 'Employees', req: ['EmployeeCode', 'FullName', 'Email', 'Department', 'Role'], opt: ['ReportingManager', 'Active'],
    rules: 'Code and e-mail unique \u00B7 Department must exist \u00B7 Role = Requestor, HRAD, Admin, ReportingManager, DeptHead or DivHead \u00B7 ReportingManager = employee code or e-mail (existing or in this file), no loops, blank keeps the current manager' }
};

interface Props { api: ApiService; entity: string; onClose: () => void; onImported: (msg: string) => void; }

/** Admin: import master data from Excel. Choose file -> automatic validation (nothing saved) -> fix errors or import. All-or-nothing. */
const ExcelImportPanel: React.FC<Props> = ({ api, entity, onClose, onImported }) => {
  const spec = SPECS[entity];
  const [file, setFile] = useState<File>();
  const [report, setReport] = useState<ImportReport>();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [view, setView] = useState('errors');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(5);
  if (!spec) return null;

  const form = (f: File): FormData => { const fd = new FormData(); fd.append('file', f); return fd; };
  const pick = async (f?: File): Promise<void> => {
    setFile(undefined); setReport(undefined); setErr(undefined); setPage(1);
    if (!f) return;
    if (!/\.xlsx$/i.test(f.name)) { setErr('Only .xlsx files are supported (found "' + f.name + '").'); return; }
    if (f.size > 5 * 1024 * 1024) { setErr('The file is larger than 5 MB.'); return; }
    setFile(f); setBusy(true);
    try { const r = await api.postForm<ImportReport>('import/' + entity + '/validate', form(f)); setReport(r); setView(r.errors.length ? 'errors' : 'preview'); }
    catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };
  const commit = async (): Promise<void> => {
    if (!file) return;
    setBusy(true); setErr(undefined);
    try {
      const r = await api.postForm<ImportReport>('import/' + entity + '/commit', form(file));
      if (r.applied) { onImported(r.message); onClose(); return; }
      setReport(r); setView('errors'); setErr(r.message);
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };
  const errorReport = (): void => {
    if (!report) return;
    downloadText(entity + '-import-errors.csv', ['Row,Column,Value,Problem'].concat(report.errors.map(e => [e.row || '', e.column, e.value, e.message].map(csvCell).join(','))).join('\r\n'));
  };
  const download = (kind: string): void => { api.download('import/' + entity + '/' + kind, entity + '-' + kind + '.xlsx').catch((e: Error) => setErr(e.message)); };

  const ne = report ? report.errors.length : 0;
  const nv = report ? report.plan.length : 0;
  const nw = report ? report.warnings.length : 0;
  const list: any[] = !report ? [] : view === 'errors' ? report.errors : view === 'preview' ? report.plan : report.warnings;
  const shown = list.slice((page - 1) * size, page * size);
  const tabs: [string, string][] = [['errors', 'Errors (' + ne + ')'], ['preview', 'Rows to import (' + nv + ')']];
  if (nw) tabs.push(['warnings', 'Warnings (' + nw + ')']);

  return (
    <Modal onClose={onClose} wide>
      <h2>Import {spec.title.toLowerCase()} from Excel</h2>
      <div className="note">1 Download the template {'\u00B7'} 2 Fill it in {'\u00B7'} 3 Upload (checked automatically) {'\u00B7'} 4 Import. Nothing is saved until you click Import, and one error blocks the whole import.</div>
      <div className="row" style={{ margin: '10px 0' }}>
        <Btn v="g" s onClick={() => download('template')}>Download template</Btn><Btn v="g" s onClick={() => download('export')}>Export current data</Btn>
      </div>
      <div className="tw"><table>
        <thead><tr><th>Required columns</th><th>Optional columns</th></tr></thead>
        <tbody><tr><td style={{ whiteSpace: 'normal' }}>{spec.req.join(', ')}</td><td style={{ whiteSpace: 'normal' }}>{spec.opt.join(', ')}</td></tr>
          <tr><td colSpan={2} className="mut" style={{ whiteSpace: 'normal' }}>{spec.rules}. Header in row 1 of the first sheet, up to 1000 rows, max 5 MB.</td></tr></tbody></table></div>
      <div className="row" style={{ margin: '12px 0' }}>
        <input type="file" accept=".xlsx" aria-label="Excel file" onChange={e => { pick(e.target.files ? e.target.files[0] : undefined); e.target.value = ''; }} />
      </div>
      {busy && <div className="mut">Checking the file...</div>}
      {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
      {report && (<>
        <div className="row" style={{ marginTop: 14 }}>
          <Chip bg="#6b7280">{report.fileName}</Chip><Chip bg="#2563eb">Rows {report.total}</Chip><Chip bg="#15803d">Valid {nv}</Chip>
          <Chip bg={ne ? '#dc2626' : '#15803d'}>Errors {ne}</Chip>{nw > 0 && <Chip bg="#b45309">Warnings {nw}</Chip>}
        </div>
        <div style={{ marginTop: 10 }}><Tabs sel={view} onSel={k => { setView(k); setPage(1); }} items={tabs} /></div>
        <div className="tw"><table>
          {view === 'errors' && (<><thead><tr><th>Row</th><th>Column</th><th>Value</th><th>Problem</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td colSpan={4} className="mut">No errors.</td></tr>}
              {shown.map((e, i) => <tr key={i}><td>{e.row || '\u2013'}</td><td>{e.column}</td><td>{e.value}</td><td style={{ whiteSpace: 'normal' }}>{e.message}</td></tr>)}</tbody></>)}
          {view === 'preview' && (<><thead><tr><th>Row</th><th>Action</th><th>Key</th><th>Name</th><th>Info</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td colSpan={5} className="mut">No valid rows.</td></tr>}
              {shown.map((p, i) => <tr key={i}><td>{p.row}</td><td><Chip bg={p.update ? '#2563eb' : '#15803d'}>{p.update ? 'Update' : 'Create'}</Chip></td><td>{p.show[0]}</td><td>{p.show[1]}</td><td>{p.show[2]}</td></tr>)}</tbody></>)}
          {view === 'warnings' && <tbody>{shown.map((w, i) => <tr key={i}><td style={{ whiteSpace: 'normal' }}>{w}</td></tr>)}</tbody>}
        </table></div>
        <Pager page={page} total={list.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
        {ne > 0 && <div className="warn" style={{ marginTop: 10 }}>Import is blocked until all {ne} error(s) are fixed. Correct your Excel file and upload it again.</div>}
      </>)}
      <div className="row" style={{ marginTop: 12 }}>
        <Btn disabled={busy || !report || ne > 0 || nv === 0} onClick={commit}>Import {nv} row(s)</Btn>
        {ne > 0 && <Btn v="g" onClick={errorReport}>Download error report (CSV)</Btn>}
        <Btn v="g" onClick={onClose}>Close</Btn>
      </div>
    </Modal>);
};
export default ExcelImportPanel;
