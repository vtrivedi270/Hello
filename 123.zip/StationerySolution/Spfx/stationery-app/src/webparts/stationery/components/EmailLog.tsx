import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Alert, Btn, Chip, Pager, toast } from './kit';

interface Mail { emailLogId: number; requestId?: number; toEmail: string; subject: string; status: string; errorMessage?: string; retryCount: number; createdAt: string; sentAt?: string; }
const COLOR: { [k: string]: string } = { Sent: '#15803d', Pending: '#b45309', Failed: '#dc2626' };

/** Admin: e-mail log. Pending / failed mails are retried automatically by the API; one can also be retried manually. */
const EmailLog: React.FC<{ api: ApiService }> = ({ api }) => {
  const [rows, setRows] = useState<Mail[]>([]);
  const [total, setTotal] = useState(0);
  const [smtp, setSmtp] = useState(true);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [err, setErr] = useState<string>();

  const load = (): void => {
    api.get<{ total: number; rows: Mail[]; smtpConfigured: boolean }>('emails?page=' + page + '&pageSize=' + size + (status ? '&status=' + status : ''))
      .then(r => { setRows(r.rows); setTotal(r.total); setSmtp(r.smtpConfigured); }).catch((e: Error) => setErr(e.message));
  };
  useEffect(load, [status, page, size]);

  const retry = async (m: Mail): Promise<void> => {
    setErr(undefined);
    try {
      const r = await api.post<{ status: string; errorMessage?: string }>('emails/' + m.emailLogId + '/retry');
      if (r.status === 'Sent') toast('Mail sent'); else setErr(r.errorMessage || 'Still failing');
      load();
    } catch (e) { setErr((e as Error).message); }
  };

  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <h1>E-mail log</h1>
      <select aria-label="Status" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}>
        <option value="">All statuses</option><option>Pending</option><option>Failed</option><option>Sent</option></select>
    </div>
    <div className="note">Failed and pending mails are retried automatically every 2 minutes. You can also retry one manually.</div>
    {!smtp && <Alert kind="error">SMTP is not configured (Smtp:Host is empty). Mails stay Pending until it is set; the retry job then sends them.</Alert>}
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <div className="tw"><table>
        <thead><tr><th>Created</th><th>To</th><th>Subject</th><th>Status</th><th>Tries</th><th>Error</th><th /></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={7} className="mut">No mails.</td></tr>}
          {rows.map(m => (<tr key={m.emailLogId}>
            <td>{new Date(m.createdAt).toLocaleString('en-GB')}</td><td>{m.toEmail}</td>
            <td style={{ maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.subject}</td>
            <td><Chip bg={COLOR[m.status] || '#6b7280'}>{m.status}</Chip></td><td>{m.retryCount}</td>
            <td style={{ maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis' }} title={m.errorMessage}>{m.errorMessage || '\u2013'}</td>
            <td>{m.status !== 'Sent' && <Btn v="g" s onClick={() => retry(m)}>Retry</Btn>}</td></tr>))}
        </tbody></table></div>
      <Pager page={page} total={total} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>
  </>);
};
export default EmailLog;
