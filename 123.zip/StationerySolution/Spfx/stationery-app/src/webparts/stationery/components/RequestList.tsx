import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { ListRow, Me, RouteName } from '../models';
import { Alert, Btn, Pager, Tabs } from './kit';
import { fmt, fmtDate, STAGE, STATUS } from './ui';
import StatusChip from './StatusChip';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; }

const RequestList: React.FC<Props> = ({ api, me, go }) => {
  const priv = me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1;
  const [view, setView] = useState('pending');
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [qd, setQd] = useState('');
  const [from, setFrom] = useState(''); const [to, setTo] = useState('');
  const [dept, setDept] = useState(0);
  const [depts, setDepts] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [data, setData] = useState<{ total: number; rows: ListRow[] }>({ total: 0, rows: [] });
  const [err, setErr] = useState<string>();

  useEffect(() => { if (priv) api.get<any[]>('masters/departments?active=true').then(setDepts).catch(() => undefined); }, []);
  useEffect(() => { const t = window.setTimeout(() => { setQd(q); setPage(1); }, 300); return () => window.clearTimeout(t); }, [q]);

  const load = (): void => {
    let s = 'view=' + view + '&page=' + page + '&pageSize=' + size;
    if (status) s += '&status=' + status; if (qd) s += '&search=' + encodeURIComponent(qd);
    if (from) s += '&from=' + from; if (to) s += '&to=' + to; if (dept) s += '&deptId=' + dept;
    api.get<{ total: number; rows: ListRow[] }>('requests?' + s).then(r => { setData(r); setErr(undefined); }).catch((e: Error) => setErr(e.message));
  };
  useEffect(load, [view, status, qd, from, to, dept, page, size]);

  const submitRow = (id: number): void => { api.post('requests/' + id + '/submit').then(load).catch((e: Error) => setErr(e.message)); };
  const clear = (): void => { setQ(''); setQd(''); setStatus(''); setFrom(''); setTo(''); setDept(0); setPage(1); };

  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}><h1>Requests</h1><Btn onClick={() => go('new')}>+ New request</Btn></div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <Tabs sel={view} onSel={k => { setView(k); setPage(1); }} items={[['pending', 'Pending for me'], ['mine', 'My requests'], ['all', priv ? 'All' : 'Related to me']]} />
      <div className="row" style={{ margin: '14px 0' }}>
        <input placeholder="Search number, requestor" aria-label="Search" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 240 }} />
        <select aria-label="Status" value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>{Object.keys(STATUS).map(k => <option key={k} value={k}>{STATUS[k][0]}</option>)}</select>
        {priv && <select aria-label="Department" value={dept} onChange={e => { setDept(Number(e.target.value)); setPage(1); }}>
          <option value={0}>All departments</option>{depts.map(d => <option key={d.departmentId} value={d.departmentId}>{d.departmentName}</option>)}</select>}
        <input type="date" aria-label="From date" value={from} onChange={e => { setFrom(e.target.value); setPage(1); }} />
        <input type="date" aria-label="To date" value={to} onChange={e => { setTo(e.target.value); setPage(1); }} />
        <Btn v="g" s onClick={clear}>Clear filters</Btn>
      </div>
      <div className="tw"><table>
        <thead><tr><th>Request no</th><th>Date</th><th>Requestor</th><th>Dept</th><th>Amount</th><th>Status</th><th>With</th><th /></tr></thead>
        <tbody>
          {data.rows.length === 0 && <tr><td colSpan={8} className="mut">Nothing here.</td></tr>}
          {data.rows.map(r => (
            <tr key={r.requestId} className="cl" onClick={() => go('detail', r.requestId)}>
              <td><b>{r.requestNo}</b></td><td>{fmtDate(r.requestDate)}</td><td>{r.requestorName}</td><td>{r.departmentName}</td><td>{fmt(r.totalAmount)}</td>
              <td><StatusChip status={r.status} /></td><td>{r.currentApproverName || (r.currentStage ? STAGE[r.currentStage] : '\u2013')}</td>
              <td onClick={e => e.stopPropagation()}>
                {r.requestorId === me.employeeId && (r.status === 'Draft' || r.status === 'AmendRequired') && (<>
                  <Btn v="g" s onClick={() => go('edit', r.requestId)}>Edit</Btn>{' '}<Btn s onClick={() => submitRow(r.requestId)}>{r.status === 'Draft' ? 'Submit' : 'Resubmit'}</Btn></>)}
              </td>
            </tr>))}
        </tbody></table></div>
      <Pager page={page} total={data.total} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>
  </>);
};
export default RequestList;
