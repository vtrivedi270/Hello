import * as React from 'react';
import { useState } from 'react';
import { ApiService } from '../services/ApiService';
import { ImportReport, LineOut } from '../models';
import { Alert, Btn, Chip, Modal, Pager, Tabs } from './kit';
import { csvCell, downloadText, fmt } from './ui';

interface Props { api: ApiService; onClose: () => void; onApply: (lines: LineOut[], mode: 'replace' | 'add') => void; }

/** Requestor: import line items from Excel into the entry form. Validated on the server; nothing is saved until the request is saved. */
const LineImportPanel: React.FC<Props> = ({ api, onClose, onApply }) => {
  const [report, setReport] = useState<ImportReport>();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [mode, setMode] = useState<'replace' | 'add'>('replace');
  const [view, setView] = useState('lines');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(5);

  const pick = async (f?: File): Promise<void> => {
    setReport(undefined); setErr(undefined); setPage(1);
    if (!f) return;
    if (!/\.xlsx$/i.test(f.name)) { setErr('Only .xlsx files are supported (found "' + f.name + '").'); return; }
    if (f.size > 5 * 1024 * 1024) { setErr('The file is larger than 5 MB.'); return; }
    setBusy(true);
    try {
      const fd = new FormData(); fd.append('file', f);
      const r = await api.postForm<ImportReport>('requests/import-lines', fd);
      setReport(r); setView(r.errors.length ? 'errors' : 'lines');
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };
  const errorReport = (): void => {
    if (!report) return;
    downloadText('request-lines-import-errors.csv', ['Row,Column,Value,Problem'].concat(report.errors.map(e => [e.row || '', e.column, e.value, e.message].map(csvCell).join(','))).join('\r\n'));
  };

  const ne = report ? report.errors.length : 0;
  const lines = report && report.lines ? report.lines : [];
  const list: any[] = view === 'errors' ? (report ? report.errors : []) : lines;
  const shown = list.slice((page - 1) * size, page * size);
  const blocked = busy || !report || ne > 0 || lines.length === 0;

  return (
    <Modal onClose={onClose} wide>
      <h2>Import line items from Excel</h2>
      <div className="note">Columns: <b>ItemCode</b> (required, an active item), <b>Quantity</b> (required, 0.01 to 100000, max 2 decimals), Remarks (optional, max 200). The template lists all item codes. No duplicate items, up to 200 lines, header in row 1, max 5 MB. Nothing is saved until you save the request.</div>
      <div className="row" style={{ margin: '10px 0' }}>
        <Btn v="g" s onClick={() => api.download('requests/lines-template', 'request-lines-template.xlsx').catch((e: Error) => setErr(e.message))}>Download template</Btn>
      </div>
      <div className="row" style={{ margin: '12px 0' }}>
        <input type="file" accept=".xlsx" aria-label="Excel file" onChange={e => { pick(e.target.files ? e.target.files[0] : undefined); e.target.value = ''; }} />
      </div>
      {busy && <div className="mut">Checking the file...</div>}
      {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
      {report && (<>
        <div className="row" style={{ marginTop: 14 }}>
          <Chip bg="#6b7280">{report.fileName}</Chip><Chip bg="#2563eb">Rows {report.total}</Chip><Chip bg="#15803d">Valid {lines.length}</Chip><Chip bg={ne ? '#dc2626' : '#15803d'}>Errors {ne}</Chip>
        </div>
        <div style={{ marginTop: 10 }}><Tabs sel={view} onSel={k => { setView(k); setPage(1); }} items={[['errors', 'Errors (' + ne + ')'], ['lines', 'Valid lines (' + lines.length + ')']]} /></div>
        <div className="tw"><table>
          {view === 'errors' ? (<><thead><tr><th>Row</th><th>Column</th><th>Value</th><th>Problem</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td colSpan={4} className="mut">No errors.</td></tr>}
              {shown.map((e, i) => <tr key={i}><td>{e.row || '\u2013'}</td><td>{e.column}</td><td>{e.value}</td><td style={{ whiteSpace: 'normal' }}>{e.message}</td></tr>)}</tbody></>)
          : (<><thead><tr><th>Row</th><th>Item</th><th>Qty</th><th>Rate</th><th>Total</th><th>Remarks</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td colSpan={6} className="mut">No valid lines.</td></tr>}
              {shown.map((l: LineOut, i) => <tr key={i}><td>{l.row}</td><td>{l.itemCode} {'\u2013'} {l.itemName}</td><td>{l.quantity} {l.unit}</td><td>{fmt(l.rate)}</td><td>{fmt(l.rate * l.quantity)}</td><td>{l.remarks || ''}</td></tr>)}</tbody></>)}
        </table></div>
        <Pager page={page} total={list.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
        <div className="row" style={{ marginTop: 12 }}>
          <label><input type="radio" name="sh-lmode" checked={mode === 'replace'} onChange={() => setMode('replace')} /> Replace current lines</label>
          <label><input type="radio" name="sh-lmode" checked={mode === 'add'} onChange={() => setMode('add')} /> Add to current lines (same item: quantities are added)</label>
        </div>
        {ne > 0 && <div className="warn" style={{ marginTop: 8 }}>Apply is blocked: {ne} error(s) found. Fix them in your Excel file and upload it again.</div>}
      </>)}
      <div className="row" style={{ marginTop: 12 }}>
        <Btn disabled={blocked} onClick={() => { onApply(lines, mode); onClose(); }}>Apply {lines.length} line(s)</Btn>
        {ne > 0 && <Btn v="g" onClick={errorReport}>Download error report (CSV)</Btn>}
        <Btn v="g" onClick={onClose}>Close</Btn>
      </div>
    </Modal>);
};
export default LineImportPanel;
