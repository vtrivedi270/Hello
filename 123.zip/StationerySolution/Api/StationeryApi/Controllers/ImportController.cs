using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

/// <summary>Admin: Excel import / export of master data (items, categories, vendors, divisions, departments, employees).
/// validate = dry run (nothing saved). commit = validates again and imports all-or-nothing in one transaction.</summary>
[Authorize(Roles = "Admin"), ApiController, Route("api/import")]
public class ImportController(ImportService svc) : ControllerBase
{
    private static string Check(string entity) =>
        ImportService.Entities.Contains(entity.ToLowerInvariant()) ? entity.ToLowerInvariant() : throw new InvalidOperationException("Unknown master data type: " + entity);

    [HttpGet("{entity}/template")]
    public IActionResult Template(string entity) => File(svc.MasterTemplate(Check(entity)), ImportService.Xlsx, $"{Check(entity)}-template.xlsx");

    [HttpGet("{entity}/export")]
    public async Task<IActionResult> Export(string entity) => File(await svc.MasterExportAsync(Check(entity)), ImportService.Xlsx, $"{Check(entity)}-export.xlsx");

    [HttpPost("{entity}/validate"), RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<IActionResult> Validate(string entity, IFormFile file) => Ok(await svc.RunAsync(Check(entity), file, false));

    [HttpPost("{entity}/commit"), RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<IActionResult> Commit(string entity, IFormFile file) => Ok(await svc.RunAsync(Check(entity), file, true));
}
