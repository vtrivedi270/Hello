using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[Authorize, ApiController, Route("api/hrad")]
public class HradController(AppDbContext db, CurrentUser user, WorkflowService wf, PdfService pdf, EmailService mail) : ControllerBase
{
    private async Task<Employee> HradAsync()
    {
        var me = await user.GetAsync();
        if (me.Role != "HRAD") throw new UnauthorizedAccessException("HRAD only");
        return me;
    }

    /// <summary>Set approved qty / stock issue, choose vendor, generate PO PDF and email the vendor.</summary>
    [HttpPost("{id:int}/process"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> Process(int id, HradProcessDto dto)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.Include(x => x.Items).ThenInclude(i => i.Item).FirstOrDefaultAsync(x => x.RequestId == id)
            ?? throw new InvalidOperationException("Request not found");
        if (h.Status != "HRApproval") throw new InvalidOperationException("Request is not awaiting HR processing");

        foreach (var l in dto.Lines)
        {
            var ri = h.Items.FirstOrDefault(x => x.RequestItemId == l.RequestItemId) ?? throw new InvalidOperationException("Invalid line");
            if (l.ApprovedQty < 0 || l.ApprovedQty > ri.Quantity) throw new InvalidOperationException($"Approved qty for {ri.Item.ItemName} must be between 0 and {ri.Quantity:0.##}");
            if (l.IssuedFromStockQty < 0 || l.IssuedFromStockQty > l.ApprovedQty) throw new InvalidOperationException($"Store issue for {ri.Item.ItemName} cannot exceed approved qty");
            if (l.IssuedFromStockQty > ri.Item.StockQty) throw new InvalidOperationException($"Insufficient stock: {ri.Item.ItemName}");
            ri.ApprovedQty = l.ApprovedQty; ri.IssuedFromStockQty = l.IssuedFromStockQty;
            ri.OrderedQty = l.ApprovedQty - l.IssuedFromStockQty;
            ri.Item.StockQty -= l.IssuedFromStockQty;
            if (l.IssuedFromStockQty > 0)
                db.StockTransactions.Add(new StockTransaction { ItemId = ri.ItemId, TxnType = "Issue", Quantity = l.IssuedFromStockQty, RequestId = id, CreatedBy = me.Email });
        }
        var toOrder = h.Items.Sum(i => (i.ApprovedQty ?? i.Quantity) - i.IssuedFromStockQty);
        if (toOrder > 0)
        {
            if (dto.VendorId == null) throw new InvalidOperationException("Select a vendor");
            var vendor = await db.Vendors.FindAsync(dto.VendorId) ?? throw new InvalidOperationException("Invalid vendor");
            h.VendorId = vendor.VendorId; h.PODate = DateTime.Today; h.PONumber = "PO-" + h.RequestNo; h.Status = "Ordered";
            wf.AddHistory(h, "HRAD", "VendorSent", me, dto.Comments);
            await db.SaveChangesAsync();
            var bytes = await pdf.BuildVendorPoAsync(id);
            await mail.QueueAsync(id, vendor.Email, $"Purchase Order {h.PONumber}", "Please find the attached purchase order.", bytes, h.PONumber + ".pdf");
        }
        else
        {   // everything served from store
            h.Status = "Delivered"; h.CurrentStage = "Requestor"; h.CurrentApproverId = h.RequestorId;
            wf.AddHistory(h, "HRAD", "Handover", me, dto.Comments ?? "Issued from store");
            await db.SaveChangesAsync();
            await wf.NotifyAsync(h, "Items ready for collection", true);
        }
        return Ok(new { h.Status });
    }

    [HttpPost("{id:int}/deliver"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> Deliver(int id)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        if (h.Status != "Ordered") throw new InvalidOperationException("Request is not in Ordered status");
        h.Status = "Delivered"; h.CurrentStage = "Requestor"; h.CurrentApproverId = h.RequestorId;
        wf.AddHistory(h, "HRAD", "Delivered", me, "Vendor delivered, handed over to requestor");
        await db.SaveChangesAsync();
        await wf.NotifyAsync(h, "Items delivered - please verify", true);
        return Ok(new { h.Status });
    }

    /// <summary>PDF preview of the purchase order from the on-screen quantities / vendor. Nothing is saved or sent.</summary>
    [HttpPost("{id:int}/pdf-preview"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> PdfPreview(int id, HradProcessDto dto)
    {
        await HradAsync();
        return File(await pdf.BuildPreviewAsync(id, dto), "application/pdf", "PO-preview.pdf");
    }

    [HttpGet("{id:int}/pdf")]
    public async Task<IActionResult> Pdf(int id)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.AsNoTracking().FirstOrDefaultAsync(x => x.RequestId == id) ?? throw new InvalidOperationException("Request not found");
        if (me.Role is not ("HRAD" or "Admin") && h.RequestorId != me.EmployeeId) throw new UnauthorizedAccessException();
        return File(await pdf.BuildVendorPoAsync(id), "application/pdf", $"PO-{h.RequestNo}.pdf");
    }

    /// <summary>HR can add / remove / change quantity of line items on any request that is not closed.
    /// Reason is mandatory and goes to history. After the vendor order was sent the PO must be re-sent.</summary>
    [HttpPut("{id:int}/items"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> EditItems(int id, HradEditDto dto)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.Include(x => x.Items).ThenInclude(i => i.Item).FirstOrDefaultAsync(x => x.RequestId == id)
            ?? throw new InvalidOperationException("Request not found");
        if (h.Status is "Closed" or "PartialClosed" or "Rejected" or "Cancelled") throw new InvalidOperationException("Closed requests cannot be edited");
        if (string.IsNullOrWhiteSpace(dto.Reason)) throw new InvalidOperationException("Reason is required");
        if (dto.Items == null || dto.Items.Count == 0) throw new InvalidOperationException("A request needs at least one item");
        if (dto.Items.Any(i => i.Quantity <= 0)) throw new InvalidOperationException("Quantity must be greater than zero");
        var ids = dto.Items.Select(i => i.ItemId).ToList();
        if (ids.Count != ids.Distinct().Count()) throw new InvalidOperationException("Duplicate item");
        var masters = await db.Items.Where(i => ids.Contains(i.ItemId)).ToDictionaryAsync(i => i.ItemId);
        if (masters.Count != ids.Count) throw new InvalidOperationException("Invalid item");
        var post = h.Status is "Ordered" or "Delivered";

        foreach (var line in h.Items.Where(l => !ids.Contains(l.ItemId)).ToList())
        {
            if (line.IssuedFromStockQty > 0 || line.ReceivedQty > 0)
                throw new InvalidOperationException($"{line.Item.ItemName} is already issued / received and cannot be removed");
            h.Items.Remove(line); db.RequestItems.Remove(line);
        }
        foreach (var i in dto.Items)
        {
            var line = h.Items.FirstOrDefault(x => x.ItemId == i.ItemId);
            if (line != null)
            {
                if (i.Quantity < line.IssuedFromStockQty || i.Quantity < line.ReceivedQty)
                    throw new InvalidOperationException($"{line.Item.ItemName}: quantity cannot be below issued / received quantity");
                if (line.Quantity != i.Quantity)
                {
                    line.Quantity = i.Quantity;
                    if (post) { line.ApprovedQty = i.Quantity; line.OrderedQty = Math.Max(0, i.Quantity - line.IssuedFromStockQty); }
                    else line.ApprovedQty = null;
                }
                if (i.Remarks != null) line.Remarks = i.Remarks;
            }
            else
            {
                var m = masters[i.ItemId];
                if (!m.IsActive) throw new InvalidOperationException($"{m.ItemName} is inactive");
                h.Items.Add(new RequestItem { ItemId = m.ItemId, Unit = m.Unit, Rate = m.Rate, Quantity = i.Quantity, Remarks = i.Remarks,
                    ApprovedQty = post ? i.Quantity : null, OrderedQty = post ? i.Quantity : 0 });
            }
        }
        h.TotalAmount = h.Items.Sum(x => x.Quantity * x.Rate);
        wf.AddHistory(h, "HRAD", "HradEdit", me, dto.Reason);
        db.Audit("RequestHeader", h.RequestId.ToString(), "HradEdit", null, dto.Reason, me.Email);
        await db.SaveChangesAsync();
        await wf.NotifyAsync(h, "Line items updated by HR", true);
        return Ok(new { h.Status, h.TotalAmount, poResendRequired = post });
    }

    /// <summary>Partial close: order the outstanding quantity again (new PO revision).</summary>
    [HttpPost("{id:int}/reorder"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> Reorder(int id, ReorderDto dto)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.Include(x => x.Items).ThenInclude(i => i.Item).FirstOrDefaultAsync(x => x.RequestId == id)
            ?? throw new InvalidOperationException("Request not found");
        if (h.Status != "PartialClosed") throw new InvalidOperationException("Only partially closed requests can be re-ordered");
        var vendor = await db.Vendors.FirstOrDefaultAsync(v => v.VendorId == dto.VendorId && v.IsActive) ?? throw new InvalidOperationException("Select a vendor");
        foreach (var l in h.Items) l.OrderedQty = Math.Max(0, (l.ApprovedQty ?? l.Quantity) - l.ReceivedQty);
        if (h.Items.Sum(l => l.OrderedQty) <= 0) throw new InvalidOperationException("Nothing is outstanding");
        var round = await db.ApprovalHistories.CountAsync(a => a.RequestId == id && a.Action == "Reorder") + 1;
        h.VendorId = vendor.VendorId; h.PODate = DateTime.Today; h.PONumber = $"PO-{h.RequestNo}-R{round}";
        h.Status = "Ordered"; h.ClosedAt = null; h.CurrentStage = null; h.CurrentApproverId = null;
        wf.AddHistory(h, "HRAD", "Reorder", me, dto.Comments ?? "Outstanding quantity re-ordered");
        await db.SaveChangesAsync();
        await mail.QueueAsync(id, vendor.Email, $"Purchase Order {h.PONumber}", "Please find the attached purchase order for the outstanding items.", await pdf.BuildVendorPoAsync(id), h.PONumber + ".pdf");
        return Ok(new { h.Status, h.PONumber });
    }

    /// <summary>Partial close accepted as final (shortfall written off).</summary>
    [HttpPost("{id:int}/close-short"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> CloseShort(int id, ActionDto dto)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        if (h.Status != "PartialClosed") throw new InvalidOperationException("Request is not partially closed");
        if (string.IsNullOrWhiteSpace(dto.Comments)) throw new InvalidOperationException("Comment is required");
        h.Status = "Closed"; h.ClosedAt = DateTime.UtcNow;
        wf.AddHistory(h, "HRAD", "CloseShort", me, dto.Comments);
        await db.SaveChangesAsync();
        await wf.NotifyAsync(h, "Closed with shortfall", true);
        return Ok(new { h.Status });
    }

    /// <summary>Regenerate the PO PDF (e.g. after line items changed) and e-mail the vendor again.</summary>
    [HttpPost("{id:int}/resend-po"), Authorize(Roles = "HRAD")]
    public async Task<IActionResult> ResendPo(int id)
    {
        var me = await HradAsync();
        var h = await db.RequestHeaders.Include(x => x.Vendor).FirstOrDefaultAsync(x => x.RequestId == id) ?? throw new InvalidOperationException("Request not found");
        if (h.Status != "Ordered" || h.Vendor == null) throw new InvalidOperationException("No active vendor order to resend");
        wf.AddHistory(h, "HRAD", "ResendPO", me, "Revised PO sent to " + h.Vendor.VendorName);
        await db.SaveChangesAsync();
        await mail.QueueAsync(id, h.Vendor.Email, $"Revised Purchase Order {h.PONumber}", "This replaces the earlier order. Please find the revised purchase order attached.", await pdf.BuildVendorPoAsync(id), h.PONumber + ".pdf");
        return Ok();
    }
}
