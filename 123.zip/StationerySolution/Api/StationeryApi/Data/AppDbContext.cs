using Microsoft.EntityFrameworkCore;
using StationeryApi.Models;
namespace StationeryApi.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Division> Divisions => Set<Division>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<Item> Items => Set<Item>();
    public DbSet<ItemCategory> Categories => Set<ItemCategory>();
    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<RequestHeader> RequestHeaders => Set<RequestHeader>();
    public DbSet<RequestItem> RequestItems => Set<RequestItem>();
    public DbSet<ApprovalHistory> ApprovalHistories => Set<ApprovalHistory>();
    public DbSet<ApproverDelegation> Delegations => Set<ApproverDelegation>();
    public DbSet<StockTransaction> StockTransactions => Set<StockTransaction>();
    public DbSet<EmailLog> EmailLogs => Set<EmailLog>();
    public DbSet<ExceptionLog> ExceptionLogs => Set<ExceptionLog>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void ConfigureConventions(ModelConfigurationBuilder b) => b.Properties<decimal>().HavePrecision(18, 2);

    protected override void OnModelCreating(ModelBuilder m)
    {
        m.Entity<RequestHeader>().HasOne(x => x.Requestor).WithMany().HasForeignKey(x => x.RequestorId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<RequestHeader>().HasOne(x => x.CurrentApprover).WithMany().HasForeignKey(x => x.CurrentApproverId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<RequestHeader>().HasOne(x => x.Vendor).WithMany().HasForeignKey(x => x.VendorId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<RequestHeader>().HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<RequestItem>().HasOne(x => x.Item).WithMany().HasForeignKey(x => x.ItemId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<ApprovalHistory>().HasOne(x => x.Actor).WithMany().HasForeignKey(x => x.ActorId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<ApproverDelegation>().HasOne(x => x.FromEmployee).WithMany().HasForeignKey(x => x.FromEmployeeId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<ApproverDelegation>().HasOne(x => x.ToEmployee).WithMany().HasForeignKey(x => x.ToEmployeeId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<Employee>().HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<Employee>().HasOne(x => x.Division).WithMany().HasForeignKey(x => x.DivisionId).OnDelete(DeleteBehavior.NoAction);
        m.Entity<Employee>().HasOne(x => x.ReportingManager).WithMany().HasForeignKey(x => x.ReportingManagerId).OnDelete(DeleteBehavior.NoAction);
    }
}
