using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Middleware;

public class ExceptionMiddleware(RequestDelegate next, IServiceScopeFactory scopes, ILogger<ExceptionMiddleware> log)
{
    private static string? Friendly(Exception ex)
    {
        if (ex is InvalidOperationException or UnauthorizedAccessException) return ex.Message;
        if (ex is DbUpdateException { InnerException: SqlException se })
            return se.Number switch
            {
                2601 or 2627 => "A record with the same code / name / e-mail already exists.",
                547 => "This record is linked to other data (or a value is invalid). If you are deleting it, deactivate it instead.",
                515 => "A required value is missing.",
                _ => null
            };
        return null;
    }

    public async Task Invoke(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (Exception ex)
        {
            var msg = Friendly(ex);
            if (msg == null)
            {
                log.LogError(ex, "Unhandled");
                try
                {
                    using var s = scopes.CreateScope();
                    var db = s.ServiceProvider.GetRequiredService<AppDbContext>();
                    db.ExceptionLogs.Add(new ExceptionLog { Source = ex.Source, Message = ex.Message, StackTrace = ex.ToString(), RequestPath = ctx.Request.Path, UserEmail = ctx.User.FindFirst("email")?.Value });
                    await db.SaveChangesAsync();
                }
                catch { /* never fail while logging */ }
            }
            if (ctx.Response.HasStarted) throw;
            ctx.Response.StatusCode = ex is UnauthorizedAccessException ? 403 : msg != null ? 400 : 500;
            await ctx.Response.WriteAsJsonAsync(new { error = msg ?? "Something went wrong. Please try again." });
        }
    }
}
