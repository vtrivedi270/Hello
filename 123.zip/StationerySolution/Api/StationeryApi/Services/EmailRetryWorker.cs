namespace StationeryApi.Services;

/// <summary>Every 2 minutes retries mails that are still Pending or Failed (only when Smtp:Host is configured).</summary>
public class EmailRetryWorker(IServiceScopeFactory scopes, ILogger<EmailRetryWorker> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(2));
        while (await timer.WaitForNextTickAsync(ct))
        {
            try
            {
                using var s = scopes.CreateScope();
                await s.ServiceProvider.GetRequiredService<EmailService>().RetryDueAsync(s.ServiceProvider.GetRequiredService<PdfService>());
            }
            catch (Exception ex) { log.LogError(ex, "Mail retry run failed"); }
        }
    }
}
