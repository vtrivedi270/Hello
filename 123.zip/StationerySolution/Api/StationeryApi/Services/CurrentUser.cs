using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class CurrentUser(AppDbContext db, IHttpContextAccessor ctx)
{
    private Employee? _emp;
    public string Email
    {
        get
        {
            var u = ctx.HttpContext!.User;
            return (u.FindFirst("email")?.Value ?? u.FindFirst("preferred_username")?.Value ?? u.FindFirst("upn")?.Value
                ?? u.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value ?? "").ToLowerInvariant();
        }
    }
    public async Task<Employee> GetAsync() =>
        _emp ??= await db.Employees.FirstOrDefaultAsync(e => e.Email.ToLower() == Email && e.IsActive)
                 ?? throw new UnauthorizedAccessException("User not found in Employee master: " + Email);
}
