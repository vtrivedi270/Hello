# Stationery Hub – SPFx (React) + .NET Core API + SQL Server

```
Database/StationeryDB.sql        SQL Server script (tables, procs, view, seed data)
Api/StationeryApi/               .NET 8 Web API (EF Core, QuestPDF, ClosedXML)
Spfx/stationery-app/             SPFx 1.18.2 web part (React 17 + Fluent UI v8)
Docs/01-Business-Requirements.md Business requirements
```

## 1. Database
1. Open `Database/StationeryDB.sql` in SSMS and run it (creates `StationeryDB`, tables, `usp_NextRequestNo`, dashboard procs, seed data).
2. Seed employees use `@contoso.com` e-mails. **Replace them with real user UPNs** (Admin, HRAD, Dept Head, Div Head, Reporting Manager, Requestor). The UPN must match the signed-in SharePoint / Entra ID user.

Approval chain comes from data: Requestor -> `ReportingManagerId` -> Department head -> Division head -> HRAD. Empty levels (or the requestor themself) are skipped automatically.

## 2. API – JWT with role-based access
How authentication works:
```
SPFx (SharePoint user)
  |  production: Entra ID token (AadHttpClient)  ->  POST /api/auth/login
  |  local dev : { email }                        ->  POST /api/auth/dev-login
  v
API validates, looks the user up in EmployeeMaster, issues an application JWT
  claims: sub, email, name, role (one claim per role)   lifetime: Jwt:ExpiryMinutes (default 480)
  v
SPFx sends  Authorization: Bearer <JWT>  on every call; auto re-login on 401.
```
Roles inside the JWT (see `TokenService`, SQL view `vw_EmployeeRoles`):

| Role | Given to | Protects |
|---|---|---|
| Requestor | every active employee | create / edit / submit / receive own requests |
| Approver | anyone who is a Reporting Manager, Dept Head or Div Head of someone (derived) | `POST /api/requests/{id}/action` (plus "is it your turn" check) |
| HRAD | `EmployeeMaster.Role = 'HRAD'` | `POST /api/hrad/{id}/process`, `/deliver` |
| Admin | `EmployeeMaster.Role = 'Admin'` | master data `POST` / `PUT` |

Data-level rules (own requests only, approver's turn, HRAD status checks) are enforced again inside the services, so the UI is never the only guard.

### Run locally
```
cd Api/StationeryApi
# edit appsettings.json -> ConnectionStrings:Default   (change Jwt:Key to your own 32+ char secret)
dotnet restore
dotnet run            # https://localhost:7100 , Swagger: /swagger
```
Test with `StationeryApi.http` (VS Code REST Client / Rider) or Swagger: call `/api/auth/dev-login`, copy the token, click **Authorize**, paste it.
`Auth:AllowDevLogin` must be **false** in production.

### Production (Entra ID token exchange)
1. Register an app for the API (expose scope `user_impersonation`, Application ID URI `api://<client-id>`).
2. `appsettings` (use Key Vault / env vars for secrets): `Auth:AllowDevLogin=false`, `Auth:EnableEntra=true`, `AzureAd:{TenantId,ClientId,Audience}`, strong `Jwt:Key`, `Cors:Origins=https://<tenant>.sharepoint.com`.
3. Deploy (Azure App Service).

Emails: set `Smtp:*` to send; otherwise rows stay `Pending` in `EmailLog`.

## 3. SPFx web part
Requires Node 18.17+ (LTS 18), `npm i -g gulp-cli`.
```
cd Spfx/stationery-app
npm install
gulp trust-dev-cert        # once
gulp serve                 # open <site>/_layouts/15/workbench.aspx and add "Stationery Hub"
```
Web part property pane:
- **API base URL**: `https://localhost:7100/api`
- **API App ID URI**: empty for local dev (uses `/auth/dev-login` with your SharePoint e-mail); `api://<client-id>` in production.

`ApiService.ts` handles login, token caching/refresh and the Bearer header; the UI hides screens by role (`me.roles`) and shows the API's 401/403 messages.

### Package and deploy
```
gulp bundle --ship
gulp package-solution --ship        # -> sharepoint/solution/stationery-app.sppkg
```
Upload to the App Catalog; in `config/package-solution.json` `webApiPermissionRequests.resource` must equal your API app registration display name; approve it in SharePoint Admin Center > API access.

## What's new in this version
- **Cancel / withdraw** a request (requestor or Admin) until it is ordered; status `Cancelled`, reason in history.
- **HR can edit line items on any open request** (add / remove / change qty, reason mandatory, full history). After the vendor order was sent, use **Resend PO**.
- **Store stock screen** (HRAD / Admin): stock-in (receipt), adjustment with reason, movement history, low-stock filter.
- **Partial close handling**: HRAD can **re-order the shortfall** (new PO revision `-R1`, `-R2`...) or **close with shortfall**.
- **Master data full CRUD**: Items, Categories, Vendors, Divisions, Departments, Employees - list/search, add, edit, activate/deactivate, delete (API refuses delete when the record is in use). All changes are written to `AuditLog`.
- Friendly API messages for duplicate keys and in-use records.

**Existing database?** Run `Database/Upgrade_001_existing_db.sql` (adds Cancelled status, OrderedQty, stock note). New installs just run `StationeryDB.sql`.

## Delegation, e-mail retry, drafts
- **Approver delegation** (screen *Delegation*): an approver (or Admin on their behalf) names a delegate for a date range. The delegate sees the approver's pending requests under *Pending for me* and can approve / amend / reject; history shows "[On behalf of ...]". Revoke any time. The delegate is notified by e-mail. Table `ApproverDelegation`.
- **E-mail retry**: every mail is stored in `EmailLog`. A background worker retries Pending / Failed mails (PO PDFs are regenerated and re-attached). Admin screen *E-mail log* shows status and lets you retry one mail manually. Needs `Smtp:*` settings.
- **Drafts**: a Draft (or Amend-required) request can be edited and submitted from the request list (Edit / Submit buttons), from the request page, or from the entry form (Save draft / Submit).

## Lists, paging and filters
- **Requests**: tabs, search, status, department (HRAD/Admin), date range, rows per page, Clear filters, server-side paging.
- **E-mail log**: status filter and paging. **Store stock**, **Admin masters**: search, filters and paging (10 / 20 / 50 rows).
- **PO preview**: HRAD can click *Preview PDF* while processing a request to see the purchase order for the typed quantities and chosen vendor before anything is sent or saved.

## E-mail templates
- All notification mails are **HTML e-mails built from templates** (blue #0070c9 header, items table, "Open Stationery Hub" button). 14 defaults are created automatically when the API starts (`Services/EmailTemplateDefaults.cs`): approval needed, HR processing needed, approved, rejected, amendment requested, cancelled, purchase order (and revised) to vendor, items ready, items changed by HR, delivery verified, closed with shortfall, query from requestor, delegate approver.
- **Admin > E-mail templates**: edit subject and body, click a placeholder chip to insert it, see a live preview (sample data, shown in a sandboxed frame), *Send test to me*, *Reset to default*, switch a template off (then the old plain-text mail is sent).
- Placeholders: `{{AppName}} {{Date}} {{Recipient}} {{RequestNo}} {{Requestor}} {{Department}} {{Total}} {{Status}} {{Stage}} {{Approver}} {{ActionBy}} {{Comments}} {{Remarks}} {{Vendor}} {{PONumber}} {{Link}}` plus ready-made blocks `{{LinkButton}} {{ItemsTable}} {{PoItemsTable}}`.
- **Security**: values are HTML-encoded before they are inserted, so request text cannot inject markup; a template cannot contain scripts, iframes, forms, `on...=` handlers or `javascript:` links; unknown placeholders are rejected on save; subjects cannot contain line breaks.
- Set `App:BaseUrl` (the SharePoint page that hosts the web part, must be https) to show the "Open Stationery Hub" button; leave it empty to hide it. `Smtp:*` must be configured to actually send.
- Database: `StationeryDB.sql` creates `EmailTemplate` (and `EmailLog.IsHtml`). Existing database: run `Database/Upgrade_003_existing_db.sql`.

## Layout and responsive design
- The web part stretches **edge to edge** (no space left or right of the page area, also inside normal SharePoint sections). Property *Width: % of the page area* (default 100).
- Breakpoints follow the width of the app itself: xl 1280+, lg 1024+, md 768+ (menu collapses to icons), sm 480+ and xs below (menu becomes a slide-in drawer opened with the Menu button; cards, filters and forms stack; tables scroll sideways inside their card).

## Width, full screen and theme colour
- **Width**: the web part property *Width: % of the page area* (default **100**) makes the app cover that share of the page area, centered. 100 = edge to edge. For the widest result add the web part to a **full-width section** (the manifest has `supportsFullBleed`) or use a full-page app.
- **Full screen button** (top bar): browser full screen for the whole app, and *Exit full screen* to return.
- **Theme colour**: primary colour **#0070c9** (blue) with matching sidebar, charts and buttons. It is defined by the CSS variables at the top of `styles/shStyles.ts` (`--pri`, `--pri2`, `--soft`) and the sidebar gradient; the preview uses the same colours.

## SPFx look and the "View as" role dropdown
- **Same design as the preview**: the SPFx screens use the same markup and the same stylesheet as `Preview/stationery-preview.html`. The stylesheet is generated from the preview (`styles/shStyles.ts`), scoped under `.sh-root` so SharePoint styles are not touched. Fluent UI is no longer used. Only two layout adaptations were needed inside SharePoint: the left menu is not pinned to the browser height, and dialogs use a higher z-index.
- **View as dropdown (top right, like the preview)**: Requestor, Reporting Manager, Dept Head, Division Head, HRAD, Admin. It appears **only in local dev mode** (web part property *API App ID URI* empty and API setting `Auth:AllowDevLogin=true`). Choosing a person signs in again as that employee, so the API applies that person's real roles and data. In production the dropdown is hidden: the role always comes from the signed-in user.
- The seed data already contains one person per role (Vishal, A. Mehta, R. Shah, F. Desai, N. Joshi, Admin User); the label is derived from the reporting hierarchy.

## Excel import / export
**Master data (Admin > Master data > Import from Excel / Export)** - Items, Categories, Vendors, Divisions, Departments, Employees.
1. *Download template* (sheet `Data` = header row, sheet `Instructions` = columns and rules) or *Export current data* (same layout, so you can edit and re-import).
2. Upload the .xlsx. It is validated automatically and nothing is saved.
3. The screen shows Rows / Valid / Errors / Warnings, an error table (Row, Column, Value, Problem) with paging, the rows that will be created or updated, and a CSV error report.
4. *Import* is enabled only when there are no errors (all-or-nothing, one database transaction, written to `AuditLog`).

Rules: header in row 1 of the first sheet (a sheet named `Data` wins), column names ignore case / spaces, max 1000 rows and 5 MB, Active = Y or N (blank = Y). Order to import: Categories, Employees, Divisions, Departments, Items (departments need divisions, heads and managers need employees, items need categories). Employees: `ReportingManager` (code or e-mail, existing or in the same file) is checked for loops; blank keeps the current manager. Items: `StockQty` sets opening stock for NEW items only (recorded as an opening-stock movement); existing stock is never changed by import. You cannot deactivate yourself or remove your own Admin role through an import.

**Requestor line items (New / Edit request)**: *Import from Excel* (columns ItemCode, Quantity, Remarks), *Export to Excel*; the request page also has *Export items*. Rules: ItemCode must be an active item, Quantity 0.01 to 100000 with at most 2 decimals, no duplicate items, max 200 lines. Choose *Replace* or *Add* (quantities of the same item are added). Nothing is saved until the request is saved. The same rules are enforced again when saving.

API: `GET api/import/{entity}/template|export`, `POST api/import/{entity}/validate|commit` (Admin); `GET api/requests/lines-template`, `POST api/requests/import-lines`, `POST api/requests/export-lines`, `GET api/requests/{id}/export`.

## Roles and screens
| Role | Can do |
|---|---|
| Requestor | Create/edit draft, submit, track, verify delivery (close / partial close), raise query |
| Reporting Manager / Dept Head / Div Head | Approve, Ask to amend, Reject (comment required) when it is their turn |
| HRAD | Edit line items on any open request, adjust approved qty, issue from store, pick vendor, send / resend PO, mark delivered, re-order or close shortfall, manage store stock |
| Admin | Full CRUD on Items, Categories, Vendors, Divisions, Departments, Employees; may cancel any request |

`EmployeeMaster.Role` holds `Requestor`, `HRAD` or `Admin`; Approver is derived from the reporting hierarchy (Department / Division head fields and ReportingManagerId).

## Status flow
Draft -> In review (RM -> Dept Head -> Div Head) -> HR approval -> Ordered -> Delivered -> Closed / Partial closed (-> Ordered again via re-order, or Closed with shortfall). Cancelled is possible before Ordered.
Reject ends the request; Amend returns it to the requestor (resubmit restarts approval). Items fully served from store skip the vendor step.

## Known gaps / next steps
- Not compiled or run in the generation environment: run `dotnet build` and `gulp build` and fix any small issues.
- No unit tests, no EF migrations (database is script-first).
- Teams notifications and concurrent-edit protection are not included.
