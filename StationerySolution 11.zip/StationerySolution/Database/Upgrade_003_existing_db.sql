/* Run once on a database created before e-mail templates were added. */
USE StationeryDB;
GO
IF OBJECT_ID('EmailTemplate') IS NULL
  CREATE TABLE EmailTemplate (
    TemplateKey NVARCHAR(50) NOT NULL PRIMARY KEY, Name NVARCHAR(150) NOT NULL, Description NVARCHAR(300) NULL,
    Subject NVARCHAR(250) NOT NULL, BodyHtml NVARCHAR(MAX) NOT NULL, IsActive BIT NOT NULL DEFAULT 1,
    ModifiedBy NVARCHAR(256) NULL, ModifiedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME());
IF COL_LENGTH('EmailLog','IsHtml') IS NULL ALTER TABLE EmailLog ADD IsHtml BIT NOT NULL CONSTRAINT DF_Email_IsHtml DEFAULT 0;
GO
/* The 14 default templates are inserted automatically by the API at start-up (Services/EmailTemplateDefaults.cs). */
