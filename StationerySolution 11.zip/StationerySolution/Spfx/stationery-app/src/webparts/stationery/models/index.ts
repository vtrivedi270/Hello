export type Status = 'Draft' | 'InReview' | 'AmendRequired' | 'Rejected' | 'HRApproval' | 'Ordered' | 'Delivered' | 'Closed' | 'PartialClosed' | 'Cancelled';

export interface Me {
  employeeId: number; fullName: string; email: string; role: string; roles: string[]; persona: string;
  departmentName: string; divisionName: string; reportingManagerName?: string;
}
export interface Item { itemId: number; itemCode: string; itemName: string; unit: string; rate: number; stockQty: number; reorderLevel: number; isActive: boolean; }
export interface Vendor { vendorId: number; vendorName: string; email: string; isActive: boolean; }
export interface ListRow {
  requestId: number; requestNo: string; requestDate: string; requestorId: number; requestorName: string; departmentName: string;
  totalAmount: number; status: Status; currentStage?: string; currentApproverName?: string;
}
export interface DetailItem {
  requestItemId: number; itemId: number; itemName: string; unit: string; rate: number; quantity: number;
  approvedQty?: number; issuedFromStockQty: number; orderedQty: number; remarks?: string; receivedQty: number; stockQty: number; lineTotal: number;
}
export interface HistoryRow { stage: string; action: string; actorName: string; comments?: string; actionDate: string; }
export interface RequestDetail {
  requestId: number; requestNo: string; requestDate: string; requestorName: string; requestorEmail: string;
  departmentName: string; remarks?: string; totalAmount: number; status: Status; currentStage?: string;
  currentApproverEmail?: string; currentApproverName?: string; vendorName?: string; poNumber?: string;
  canAct: boolean; delegatedFrom?: string;
  items: DetailItem[]; history: HistoryRow[];
}
export interface FormLine { itemId: number; quantity: number; remarks?: string; }
export interface ImportError { row: number; column: string; value: string; message: string; }
export interface ImportPlanRow { row: number; update: boolean; show: string[]; }
export interface LineOut { row: number; itemId: number; itemCode: string; itemName: string; unit: string; rate: number; quantity: number; remarks?: string; }
export interface ImportReport {
  entity: string; fileName: string; total: number; errors: ImportError[]; warnings: string[]; plan: ImportPlanRow[];
  lines?: LineOut[]; applied: boolean; created: number; updated: number; message: string;
}
export type RouteName = 'dash' | 'list' | 'new' | 'edit' | 'detail' | 'admin' | 'stock' | 'delegation' | 'emails' | 'templates';
export interface Route { name: RouteName; id?: number; }

export const hasRole = (me: Me, role: string): boolean => me.roles.indexOf(role) > -1;
