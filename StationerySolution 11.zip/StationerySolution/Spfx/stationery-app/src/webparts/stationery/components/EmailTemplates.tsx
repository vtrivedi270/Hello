import * as React from 'react';
import { useEffect, useRef, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Alert, Btn, Chip, Field, Modal, toast } from './kit';
import { fmtDate } from './ui';

interface Row { templateKey: string; name: string; description?: string; subject: string; isActive: boolean; modifiedBy?: string; modifiedAt: string; }
interface Full extends Row { bodyHtml: string; }

/** Admin: edit the HTML e-mail templates. Placeholders such as {{RequestNo}} are replaced when a mail is sent; values are HTML-encoded by the API. */
const EmailTemplates: React.FC<{ api: ApiService }> = ({ api }) => {
  const [rows, setRows] = useState<Row[]>([]);
  const [placeholders, setPlaceholders] = useState<string[]>([]);
  const [err, setErr] = useState<string>();
  const [edit, setEdit] = useState<Full>();
  const [mErr, setMErr] = useState<string>();
  const [prev, setPrev] = useState<{ subject: string; html: string }>();
  const [busy, setBusy] = useState(false);
  const body = useRef<HTMLTextAreaElement>(null);

  const load = (): void => { api.get<{ placeholders: string[]; rows: Row[] }>('email-templates').then(r => { setRows(r.rows); setPlaceholders(r.placeholders); }).catch((e: Error) => setErr(e.message)); };
  useEffect(load, []);

  const open = async (k: string): Promise<void> => {
    setMErr(undefined); setPrev(undefined);
    try { const t = await api.get<Full>('email-templates/' + k); setEdit(t); showPreview(t); } catch (e) { setErr((e as Error).message); }
  };
  const showPreview = async (t: Full): Promise<void> => {
    try { setPrev(await api.post<{ subject: string; html: string }>('email-templates/' + t.templateKey + '/preview', { subject: t.subject, bodyHtml: t.bodyHtml })); setMErr(undefined); }
    catch (e) { setPrev(undefined); setMErr((e as Error).message); }
  };
  const insert = (p: string): void => {
    if (!edit) return;
    const el = body.current; const tag = '{{' + p + '}}';
    const s = el ? el.selectionStart : edit.bodyHtml.length; const e = el ? el.selectionEnd : s;
    setEdit({ ...edit, bodyHtml: edit.bodyHtml.slice(0, s) + tag + edit.bodyHtml.slice(e) });
    window.setTimeout(() => { if (el) { el.focus(); el.setSelectionRange(s + tag.length, s + tag.length); } }, 0);
  };
  const run = async (fn: () => Promise<any>, ok: string, close: boolean): Promise<void> => {
    setBusy(true); setMErr(undefined);
    try { await fn(); toast(ok); load(); if (close) setEdit(undefined); } catch (e) { setMErr((e as Error).message); }
    setBusy(false);
  };

  return (<>
    <h1>E-mail templates</h1>
    <div className="note">These HTML e-mails are sent for approvals, orders and notices. Use placeholders like {'{{RequestNo}}'}; values are inserted safely (HTML-encoded). Switch a template off to fall back to a plain-text mail.</div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <div className="tw"><table>
        <thead><tr><th>Template</th><th>Subject</th><th>Status</th><th>Last changed</th><th /></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={5} className="mut">No templates yet. They are created when the API starts.</td></tr>}
          {rows.map(r => (<tr key={r.templateKey} style={{ opacity: r.isActive ? 1 : 0.55 }}>
            <td><b>{r.name}</b><div className="mut" style={{ whiteSpace: 'normal' }}>{r.description}</div></td>
            <td style={{ whiteSpace: 'normal' }}>{r.subject}</td>
            <td><Chip bg={r.isActive ? '#15803d' : '#6b7280'}>{r.isActive ? 'On' : 'Off'}</Chip></td>
            <td>{fmtDate(r.modifiedAt)}<div className="mut">{r.modifiedBy}</div></td>
            <td><Btn v="g" s onClick={() => open(r.templateKey)}>Edit</Btn></td></tr>))}
        </tbody></table></div>
    </div>

    {edit && (
      <Modal onClose={() => setEdit(undefined)} wide>
        <h2>{edit.name}</h2>
        {mErr && <Alert kind="error" style={{ marginBottom: 10 }}>{mErr}</Alert>}
        <Field label="Subject"><input value={edit.subject} maxLength={250} onChange={e => setEdit({ ...edit, subject: e.target.value })} /></Field>
        <Field label="Body (HTML)" style={{ marginTop: 10 }}>
          <textarea ref={body} rows={11} value={edit.bodyHtml} spellCheck={false} style={{ fontFamily: 'Consolas, monospace', fontSize: 12 }} onChange={e => setEdit({ ...edit, bodyHtml: e.target.value })} />
        </Field>
        <div className="mut" style={{ margin: '8px 0 4px' }}>Click to insert a placeholder:</div>
        <div className="row" style={{ gap: 6 }}>{placeholders.map(p => <button type="button" key={p} className="btn g s" onClick={() => insert(p)}>{'{{' + p + '}}'}</button>)}</div>
        <div className="row" style={{ margin: '12px 0 6px' }}>
          <label><input type="checkbox" checked={edit.isActive} onChange={e => setEdit({ ...edit, isActive: e.target.checked })} /> Template is on</label>
          <Btn v="g" s onClick={() => showPreview(edit)}>Refresh preview</Btn>
        </div>
        <div className="mut">Preview with sample data{prev ? ' \u00B7 subject: ' + prev.subject : ''}</div>
        <iframe title="E-mail preview" sandbox="" srcDoc={prev ? prev.html : ''} style={{ width: '100%', height: 340, border: '1px solid var(--line)', borderRadius: 8, background: '#fff', marginTop: 6 }} />
        <div className="row" style={{ marginTop: 12 }}>
          <Btn disabled={busy} onClick={() => run(() => api.put('email-templates/' + edit.templateKey, { subject: edit.subject, bodyHtml: edit.bodyHtml, isActive: edit.isActive }), 'Template saved', true)}>Save</Btn>
          <Btn v="g" disabled={busy} onClick={() => run(() => api.post('email-templates/' + edit.templateKey + '/test'), 'Test mail queued to your address (saved version)', false)}>Send test to me</Btn>
          <Btn v="g" disabled={busy} onClick={() => { if (window.confirm('Restore the original text of this template?')) run(() => api.post<Full>('email-templates/' + edit.templateKey + '/reset').then(t => { setEdit(t); showPreview(t); }), 'Template reset to default', false); }}>Reset to default</Btn>
          <Btn v="g" onClick={() => setEdit(undefined)}>Close</Btn>
        </div>
      </Modal>)}
  </>);
};
export default EmailTemplates;
