import * as React from 'react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Me, Route, RouteName } from '../models';
import { Alert } from './kit';
import SideNav from './SideNav';
import Dashboard from './Dashboard';
import RequestList from './RequestList';
import RequestForm from './RequestForm';
import RequestDetailView from './RequestDetailView';
import Admin from './Admin';
import Stock from './Stock';
import Delegation from './Delegation';
import EmailLog from './EmailLog';
import EmailTemplates from './EmailTemplates';

interface Props { api: ApiService; screenPercent?: number; }
interface DevUser { employeeId: number; fullName: string; email: string; persona: string; }
const PERSONAS = ['Requestor', 'Reporting Manager', 'Dept Head', 'Division Head', 'HRAD', 'Admin'];
/** Breakpoints follow the width of the app itself (not the browser window), because SharePoint sections can be narrower than the screen. */
const bpOf = (w: number): string => w < 480 ? 'xs' : w < 768 ? 'sm' : w < 1024 ? 'md' : w < 1280 ? 'lg' : 'xl';

const App: React.FC<Props> = ({ api, screenPercent }) => {
  const [me, setMe] = useState<Me>();
  const [err, setErr] = useState<string>();
  const [route, setRoute] = useState<Route>({ name: 'dash' });
  const [pending, setPending] = useState(0);
  const [devUsers, setDevUsers] = useState<DevUser[]>([]);
  const rootRef = useRef<HTMLDivElement>(null);
  const [box, setBox] = useState<{ w: number; ml: number }>();
  const [bp, setBp] = useState('xl');
  const [collapsed, setCollapsed] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [fs, setFs] = useState(false);
  const pct = screenPercent && screenPercent >= 50 && screenPercent <= 100 ? screenPercent : 100;
  const isDrawer = bp === 'sm' || bp === 'xs';

  /** Full width: SharePoint puts padding / margins around web parts. Measure where the page area starts and stretch the app
   *  to its full width (edge to edge, no space on the left or right). Works in normal and full-width sections. */
  const measure = (): void => {
    const el = rootRef.current;
    if (!el || document.fullscreenElement) return;
    const region = el.closest('[data-automation-id="contentScrollRegion"]') as HTMLElement | null;
    const regLeft = region ? region.getBoundingClientRect().left : 0;
    const regW = region ? region.clientWidth : document.documentElement.clientWidth;
    const curMl = parseFloat(el.style.marginLeft) || 0;
    const natural = el.getBoundingClientRect().left - curMl;
    const w = Math.max(320, Math.round(regW * pct / 100));
    const ml = Math.round(regLeft + (regW - w) / 2 - natural);
    setBox(b => b && b.w === w && b.ml === ml ? b : { w: w, ml: ml });
    const nb = bpOf(w);
    setBp(prev => prev === nb ? prev : nb);
  };
  useLayoutEffect(() => {
    measure();
    const onResize = (): void => measure();
    window.addEventListener('resize', onResize);
    let ro: ResizeObserver | undefined;
    const parent = rootRef.current ? rootRef.current.parentElement : null;
    if (typeof ResizeObserver !== 'undefined' && parent) { ro = new ResizeObserver(onResize); ro.observe(parent); }
    return () => { window.removeEventListener('resize', onResize); if (ro) ro.disconnect(); };
  }, [pct]);
  useEffect(() => { setCollapsed(bp === 'md'); setDrawer(false); }, [bp]);
  useEffect(() => { const h = (): void => { setFs(!!document.fullscreenElement); window.setTimeout(measure, 50); }; document.addEventListener('fullscreenchange', h); return () => document.removeEventListener('fullscreenchange', h); }, []);
  const toggleFs = (): void => {
    if (document.fullscreenElement) { document.exitFullscreen(); return; }
    if (rootRef.current && rootRef.current.requestFullscreen) rootRef.current.requestFullscreen().catch(() => undefined);
  };

  const loadMe = (): Promise<void> => api.get<Me>('me').then(setMe).catch((e: Error) => setErr(e.message));
  useEffect(() => { loadMe().then(() => { if (api.devMode) api.devUsers().then(setDevUsers).catch(() => undefined); }); }, []);
  useEffect(() => { if (me) api.get<{ total: number }>('requests?view=pending&page=1&pageSize=1').then(r => setPending(r.total)).catch(() => undefined); }, [me, route.name, route.id]);

  const go = (name: RouteName, id?: number): void => { setDrawer(false); setRoute({ name: name, id: id }); window.scrollTo(0, 0); };

  /** "View as": dev mode only. Signs in again as the chosen person, so the API applies that person's real roles. */
  const viewAs = async (email: string): Promise<void> => {
    try { await api.switchUser(email); setMe(undefined); await loadMe(); setRoute({ name: 'dash' }); }
    catch (e) { setErr((e as Error).message); }
  };

  const rootStyle: React.CSSProperties = fs ? {} : box ? { width: box.w, marginLeft: box.ml } : { width: '100%' };
  const shell = (children: React.ReactNode): JSX.Element => <div className="sh-root" ref={rootRef} data-bp={bp} style={rootStyle}>{children}</div>;
  if (err && !me) return shell(<div className="page"><Alert kind="error">Cannot load your profile: {err}</Alert></div>);
  if (!me) return shell(<div className="page"><span className="mut">Loading Stationery Hub...</span></div>);

  const has = (r: string): boolean => me.roles.indexOf(r) > -1;
  const active: RouteName = route.name === 'detail' || route.name === 'edit' ? 'list' : route.name;
  const blocked = (m: string): JSX.Element => <Alert kind="error">{m}</Alert>;
  let view: React.ReactNode;
  switch (route.name) {
    case 'list': view = <RequestList api={api} me={me} go={go} />; break;
    case 'new': view = <RequestForm api={api} me={me} go={go} />; break;
    case 'edit': view = <RequestForm api={api} me={me} go={go} requestId={route.id} />; break;
    case 'detail': view = <RequestDetailView api={api} me={me} go={go} requestId={route.id!} />; break;
    case 'stock': view = has('HRAD') || has('Admin') ? <Stock api={api} /> : blocked('HRAD or Admin access required'); break;
    case 'delegation': view = <Delegation api={api} me={me} />; break;
    case 'templates': view = has('Admin') ? <EmailTemplates api={api} /> : blocked('Admin access required'); break;
    case 'emails': view = has('Admin') ? <EmailLog api={api} /> : blocked('Admin access required'); break;
    case 'admin': view = has('Admin') ? <Admin api={api} /> : blocked('Admin access required'); break;
    default: view = <Dashboard api={api} me={me} go={go} />;
  }

  const options = devUsers.slice().sort((a, b) => PERSONAS.indexOf(a.persona) - PERSONAS.indexOf(b.persona) || a.fullName.localeCompare(b.fullName));
  return shell(
    <div className="shell">
      <div className={'drawer-bg' + (isDrawer && drawer ? ' show' : '')} onClick={() => setDrawer(false)} />
      <SideNav me={me} active={active} pending={pending} collapsed={collapsed} drawer={isDrawer} open={drawer}
        onToggle={() => isDrawer ? setDrawer(false) : setCollapsed(!collapsed)} go={go} />
      <div className="main">
        <header className="top">
          <button type="button" className="btn g s menu-btn" aria-label="Open menu" onClick={() => setDrawer(!drawer)}>{'\u2630'} Menu</button>
          <div className="crumb">SharePoint {'\u203A'} Stationery {'\u203A'} {route.name}</div>
          <div className="who">
            <button type="button" className="btn g s" onClick={toggleFs} aria-pressed={fs} title="Full screen">{fs ? 'Exit full screen' : 'Full screen'}</button>
            {api.devMode && options.length > 0 ? (<>
              <label className="mut" htmlFor="sh-viewas">View as</label>
              <select id="sh-viewas" value={me.email.toLowerCase()} onChange={e => viewAs(e.target.value)}>
                {PERSONAS.map(p => options.some(o => o.persona === p) && (
                  <optgroup key={p} label={p}>{options.filter(o => o.persona === p).map(o => <option key={o.employeeId} value={o.email.toLowerCase()}>{p} {'\u00B7'} {o.fullName}</option>)}</optgroup>))}
              </select></>)
              : <span className="mut">{me.fullName} {'\u00B7'} {me.persona}</span>}
          </div>
        </header>
        <main className="page">{err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}{view}</main>
      </div>
    </div>);
};
export default App;
