using System.Net;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class EmailService(AppDbContext db, IConfiguration cfg, ILogger<EmailService> log, EmailTemplateService tpl)
{
    public bool SmtpConfigured => !string.IsNullOrWhiteSpace(cfg["Smtp:Host"]);

    /// <summary>Store the mail in EmailLog and try to send it now. Failures are retried by EmailRetryWorker.</summary>
    public async Task QueueAsync(int? requestId, string to, string subject, string body, byte[]? pdf = null, string? pdfName = null, bool html = false)
    {
        var m = new EmailLog { RequestId = requestId, ToEmail = to, Subject = subject, Body = body, AttachPo = pdf != null, IsHtml = html };
        db.EmailLogs.Add(m);
        await db.SaveChangesAsync();
        if (SmtpConfigured) await SendAsync(m, pdf, pdfName);
    }

    public async Task SendAsync(EmailLog m, byte[]? pdf, string? pdfName)
    {
        m.LastAttemptAt = DateTime.UtcNow;
        try
        {
            using var c = new SmtpClient(cfg["Smtp:Host"], cfg.GetValue("Smtp:Port", 587)) { EnableSsl = true, Credentials = new NetworkCredential(cfg["Smtp:User"], cfg["Smtp:Password"]) };
            using var msg = new MailMessage(cfg["Smtp:From"]!, m.ToEmail, m.Subject, m.Body ?? "") { IsBodyHtml = m.IsHtml };
            if (pdf != null) msg.Attachments.Add(new Attachment(new MemoryStream(pdf), pdfName ?? "PO.pdf", "application/pdf"));
            await c.SendMailAsync(msg);
            m.Status = "Sent"; m.SentAt = DateTime.UtcNow; m.ErrorMessage = null;
        }
        catch (Exception ex)
        {
            m.Status = "Failed"; m.ErrorMessage = ex.Message; m.RetryCount++;
            log.LogError(ex, "Mail failed to {To}", m.ToEmail);
        }
        await db.SaveChangesAsync();
    }

    /// <summary>Queue a mail built from an e-mail template for a request (items table, approver, totals ... are filled automatically).
    /// If the template is missing or switched off, the plain-text fallback is sent instead.</summary>
    public async Task QueueRequestMailAsync(int requestId, string to, string key, Dictionary<string, string>? extra = null, string? fallbackSubject = null, string? fallbackBody = null, byte[]? pdf = null, string? pdfName = null)
    {
        var (plain, raw) = await tpl.BuildRequestModelAsync(requestId);
        if (extra != null) foreach (var kv in extra) plain[kv.Key] = kv.Value ?? "";
        if (!plain.ContainsKey("Recipient"))
            plain["Recipient"] = await db.Employees.Where(e => e.Email == to).Select(e => e.FullName).FirstOrDefaultAsync() ?? "there";
        foreach (var k in new[] { "ActionBy", "Comments" }) if (!plain.ContainsKey(k)) plain[k] = "";
        var r = await tpl.RenderAsync(key, plain, raw);
        if (r == null) { await QueueAsync(requestId, to, fallbackSubject ?? $"[Stationery] {plain.GetValueOrDefault("RequestNo")}", fallbackBody ?? "", pdf, pdfName); return; }
        await QueueAsync(requestId, to, r.Value.Subject, r.Value.Html, pdf, pdfName, html: true);
    }

    /// <summary>Template mail that is not about a request (for example the delegation notice).</summary>
    public async Task QueueTemplateAsync(string to, string key, Dictionary<string, string> extra, string fallbackSubject, string fallbackBody)
    {
        var (plain, raw) = tpl.BaseModel();
        foreach (var kv in extra) plain[kv.Key] = kv.Value ?? "";
        if (!plain.ContainsKey("Recipient")) plain["Recipient"] = await db.Employees.Where(e => e.Email == to).Select(e => e.FullName).FirstOrDefaultAsync() ?? "there";
        var r = await tpl.RenderAsync(key, plain, raw);
        if (r == null) await QueueAsync(null, to, fallbackSubject, fallbackBody);
        else await QueueAsync(null, to, r.Value.Subject, r.Value.Html, html: true);
    }

    /// <summary>Purchase order mail to the vendor (template po-vendor / po-vendor-revised) with the PDF attached.</summary>
    public Task QueuePoAsync(int requestId, Vendor vendor, bool revised, byte[] pdf, string pdfName) =>
        QueueRequestMailAsync(requestId, vendor.Email, revised ? "po-vendor-revised" : "po-vendor", new() { ["Recipient"] = vendor.ContactPerson ?? vendor.VendorName, ["Vendor"] = vendor.VendorName },
            revised ? "Revised Purchase Order " + pdfName : "Purchase Order " + pdfName, "Please find the attached purchase order.", pdf, pdfName);

    /// <summary>Re-send one logged mail (regenerates the PO PDF when it had one).</summary>
    public async Task RetryOneAsync(EmailLog m, PdfService pdf)
    {
        byte[]? bytes = null; string? name = null;
        if (m.AttachPo && m.RequestId != null)
        {
            bytes = await pdf.BuildVendorPoAsync(m.RequestId.Value);
            name = (await db.RequestHeaders.Where(r => r.RequestId == m.RequestId).Select(r => r.PONumber).FirstOrDefaultAsync() ?? "PO") + ".pdf";
        }
        await SendAsync(m, bytes, name);
    }

    /// <summary>Called by the background worker: retry Pending / Failed mails with back-off (max 5 tries).</summary>
    public async Task RetryDueAsync(PdfService pdf)
    {
        if (!SmtpConfigured) return;
        var now = DateTime.UtcNow;
        var due = await db.EmailLogs.Where(x => (x.Status == "Pending" || x.Status == "Failed") && x.RetryCount < 5)
            .OrderBy(x => x.EmailLogId).Take(50).ToListAsync();
        foreach (var m in due)
        {
            if (m.LastAttemptAt != null && m.LastAttemptAt > now.AddMinutes(-5 * (m.RetryCount + 1))) continue;
            await RetryOneAsync(m, pdf);
        }
    }
}
