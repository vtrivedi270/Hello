using System.Globalization;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

/// <summary>Loads, validates and renders the HTML e-mail templates. Plain values are HTML-encoded; only the generated blocks
/// (ItemsTable, PoItemsTable, LinkButton) are inserted as HTML, so request text can never inject markup into a mail.</summary>
public class EmailTemplateService(AppDbContext db, IConfiguration cfg)
{
    private static readonly Regex Ph = new(@"\{\{\s*([A-Za-z0-9_]+)\s*\}\}", RegexOptions.Compiled);
    private static readonly Regex Unsafe = new(@"<\s*(script|iframe|object|embed|form|link|meta|base)\b|javascript\s*:|\son\w+\s*=", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Dictionary<string, string> StageNames = new()
        { ["ReportingManager"] = "Reporting Manager", ["DeptHead"] = "Dept Head", ["DivHead"] = "Division Head", ["HRAD"] = "HRAD", ["Requestor"] = "Requestor" };
    private static readonly Dictionary<string, string> StatusNames = new()
        { ["InReview"] = "In review", ["AmendRequired"] = "Amend required", ["HRApproval"] = "HR approval", ["PartialClosed"] = "Partial closed" };

    public string AppName => cfg["App:Name"] ?? "Stationery Hub";

    public const string Layout = """
        <!doctype html><html><body style="margin:0;background:#f3f4f8;font-family:'Segoe UI',Arial,sans-serif;color:#1f2433">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f8;padding:24px 0"><tr><td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%">
        <tr><td style="background:#0070c9;color:#ffffff;padding:18px 24px;border-radius:12px 12px 0 0;font-size:18px;font-weight:700">{{AppName}}</td></tr>
        <tr><td style="background:#ffffff;padding:24px;border:1px solid #e3e6ee;border-top:0;border-radius:0 0 12px 12px;font-size:14px;line-height:1.5">{{Content}}</td></tr>
        <tr><td style="padding:14px 8px;font-size:12px;color:#5b6275;text-align:center">This is an automated message from {{AppName}}. Please do not reply.</td></tr>
        </table></td></tr></table></body></html>
        """;

    public async Task EnsureSeedAsync()
    {
        var have = (await db.EmailTemplates.Select(t => t.TemplateKey).ToListAsync()).ToHashSet();
        foreach (var d in EmailTemplateDefaults.All.Where(d => !have.Contains(d.Key)))
            db.EmailTemplates.Add(new EmailTemplate { TemplateKey = d.Key, Name = d.Name, Description = d.Description, Subject = d.Subject, BodyHtml = d.Body.Trim(), ModifiedBy = "system" });
        await db.SaveChangesAsync();
    }

    // ---------- rendering ----------
    private static string Fill(string text, IDictionary<string, string> plain, IDictionary<string, string>? raw, bool encode) =>
        Ph.Replace(text, m =>
        {
            var k = m.Groups[1].Value;
            if (raw != null && raw.TryGetValue(k, out var h)) return h;
            return plain.TryGetValue(k, out var v) ? (encode ? WebUtility.HtmlEncode(v) : v) : "";
        });

    public (string Subject, string Html) RenderText(string subject, string body, IDictionary<string, string> plain, IDictionary<string, string> raw)
    {
        var s = Fill(subject, plain, null, false).Replace("\r", " ").Replace("\n", " ").Trim();
        var content = Fill(body, plain, raw, true);
        var page = Layout.Replace("{{Content}}", content).Replace("{{AppName}}", WebUtility.HtmlEncode(AppName));
        return (s, page);
    }

    /// <summary>Renders an active template; null when it is missing or switched off (the caller then sends the plain-text fallback).</summary>
    public async Task<(string Subject, string Html)?> RenderAsync(string key, IDictionary<string, string> plain, IDictionary<string, string> raw)
    {
        var t = await db.EmailTemplates.AsNoTracking().FirstOrDefaultAsync(x => x.TemplateKey == key && x.IsActive);
        return t == null ? null : RenderText(t.Subject, t.BodyHtml, plain, raw);
    }

    /// <summary>Returns a list of problems (empty = valid).</summary>
    public static List<string> Validate(string subject, string body)
    {
        var errs = new List<string>();
        if (string.IsNullOrWhiteSpace(subject)) errs.Add("Subject is required");
        else if (subject.Length > 250) errs.Add("Subject is too long (max 250 characters)");
        if (string.IsNullOrWhiteSpace(body)) errs.Add("Body is required");
        else if (body.Length > 20000) errs.Add("Body is too long (max 20000 characters)");
        if (Unsafe.IsMatch(body ?? "")) errs.Add("Body must not contain scripts, iframes, forms, event handlers (onclick=...) or javascript: links");
        var allowed = EmailTemplateDefaults.Placeholders.ToHashSet();
        var unknown = Ph.Matches((subject ?? "") + " " + (body ?? "")).Select(m => m.Groups[1].Value).Where(k => !allowed.Contains(k)).Distinct().ToList();
        if (unknown.Count > 0) errs.Add("Unknown placeholder(s): " + string.Join(", ", unknown.Select(u => "{{" + u + "}}")) + ". Allowed: " + string.Join(", ", EmailTemplateDefaults.Placeholders.Select(p => "{{" + p + "}}")));
        return errs;
    }

    // ---------- data for the placeholders ----------
    public (Dictionary<string, string> plain, Dictionary<string, string> raw) BaseModel() => Base();

    private string? LinkUrl()
    {
        var u = cfg["App:BaseUrl"];
        return !string.IsNullOrWhiteSpace(u) && (u.StartsWith("https://") || u.StartsWith("http://localhost")) ? u : null;
    }

    private (Dictionary<string, string> plain, Dictionary<string, string> raw) Base()
    {
        var plain = new Dictionary<string, string> { ["AppName"] = AppName, ["Date"] = DateTime.Today.ToString("dd MMM yyyy", CultureInfo.InvariantCulture), ["Link"] = LinkUrl() ?? "" };
        var raw = new Dictionary<string, string>();
        var url = LinkUrl();
        raw["LinkButton"] = url == null ? "" : $"<p style=\"margin:16px 0 0\"><a href=\"{WebUtility.HtmlEncode(url)}\" style=\"display:inline-block;background:#0070c9;color:#ffffff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:600\">Open {WebUtility.HtmlEncode(AppName)}</a></p>";
        return (plain, raw);
    }

    private static string Money(decimal v) => "\u20B9" + v.ToString("N2", new CultureInfo("en-IN"));

    private static string Table(string[] heads, IEnumerable<string[]> rows)
    {
        var sb = new StringBuilder("<table style=\"border-collapse:collapse;width:100%;margin:12px 0;font-size:13px\"><tr>");
        foreach (var h in heads) sb.Append($"<th align=\"left\" style=\"padding:8px;border-bottom:2px solid #e3e6ee;color:#5b6275\">{WebUtility.HtmlEncode(h)}</th>");
        sb.Append("</tr>");
        foreach (var r in rows) { sb.Append("<tr>"); foreach (var c in r) sb.Append($"<td style=\"padding:8px;border-bottom:1px solid #e3e6ee\">{WebUtility.HtmlEncode(c)}</td>"); sb.Append("</tr>"); }
        return sb.Append("</table>").ToString();
    }

    public async Task<(Dictionary<string, string> plain, Dictionary<string, string> raw)> BuildRequestModelAsync(int requestId)
    {
        var (plain, raw) = Base();
        var h = await db.RequestHeaders.AsNoTracking().AsSplitQuery().Include(x => x.Requestor).Include(x => x.Department).Include(x => x.CurrentApprover)
            .Include(x => x.Vendor).Include(x => x.Items).ThenInclude(i => i.Item).FirstOrDefaultAsync(x => x.RequestId == requestId);
        if (h == null) return (plain, raw);
        plain["RequestNo"] = h.RequestNo; plain["Requestor"] = h.Requestor.FullName; plain["Department"] = h.Department?.DepartmentName ?? "";
        plain["Total"] = Money(h.TotalAmount); plain["Status"] = StatusNames.GetValueOrDefault(h.Status, h.Status);
        plain["Stage"] = h.CurrentStage == null ? "" : StageNames.GetValueOrDefault(h.CurrentStage, h.CurrentStage);
        plain["Approver"] = h.CurrentApprover?.FullName ?? ""; plain["Remarks"] = h.Remarks ?? "-"; plain["PONumber"] = h.PONumber ?? ""; plain["Vendor"] = h.Vendor?.VendorName ?? "";
        raw["ItemsTable"] = Table(["Item", "Qty", "Rate", "Total"], h.Items.Select(i => new[] { i.Item.ItemName, $"{i.Quantity:0.##} {i.Unit}", Money(i.Rate), Money(i.Quantity * i.Rate) }));
        raw["PoItemsTable"] = Table(["Item", "Qty", "Rate", "Amount"], h.Items.Where(i => i.OrderedQty > 0).Select(i => new[] { i.Item.ItemName, $"{i.OrderedQty:0.##} {i.Unit}", Money(i.Rate), Money(i.OrderedQty * i.Rate) }));
        return (plain, raw);
    }

    /// <summary>Sample data for the Admin preview / test mail.</summary>
    public (Dictionary<string, string> plain, Dictionary<string, string> raw) SampleModel()
    {
        var (plain, raw) = Base();
        if (raw["LinkButton"] == "")   // show the button in the preview even when App:BaseUrl is not configured
            raw["LinkButton"] = $"<p style=\"margin:16px 0 0\"><a href=\"#\" style=\"display:inline-block;background:#0070c9;color:#ffffff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:600\">Open {WebUtility.HtmlEncode(AppName)}</a></p>";
        plain["RequestNo"] = "STN-2026-00042"; plain["Requestor"] = "Vishal"; plain["Department"] = "IT"; plain["Total"] = Money(1740); plain["Status"] = "In review";
        plain["Stage"] = "Dept Head"; plain["Approver"] = "R. Shah"; plain["ActionBy"] = "A. Mehta"; plain["Comments"] = "Looks fine, please proceed."; plain["Remarks"] = "Quarterly office supplies";
        plain["Vendor"] = "Rajkot Office Mart"; plain["PONumber"] = "PO-STN-2026-00042"; plain["Recipient"] = "Alex";
        var rows = new[] { new[] { "A4 Paper Ream", "5 Ream", Money(280), Money(1400) }, new[] { "Ball Pen Blue", "20 Nos", Money(10), Money(200) }, new[] { "Stapler Pins", "4 Box", Money(35), Money(140) } };
        raw["ItemsTable"] = Table(["Item", "Qty", "Rate", "Total"], rows); raw["PoItemsTable"] = Table(["Item", "Qty", "Rate", "Amount"], rows);
        return (plain, raw);
    }
}
