namespace StationeryApi.Services;

public sealed record TemplateDef(string Key, string Name, string Description, string Subject, string Body);

/// <summary>Built-in e-mail templates. They are copied into the EmailTemplate table on first start; Admin can then edit them
/// (Admin &gt; E-mail templates) and "Reset to default" restores the text below.
/// Placeholders (written {{Name}}): AppName, Date, Recipient, RequestNo, Requestor, Department, Total, Status, Stage, Approver,
/// ActionBy, Comments, Remarks, Vendor, PONumber, Link, plus the ready-made HTML blocks LinkButton, ItemsTable and PoItemsTable.</summary>
public static class EmailTemplateDefaults
{
    public static readonly string[] Placeholders =
    [
        "AppName", "Date", "Recipient", "RequestNo", "Requestor", "Department", "Total", "Status", "Stage", "Approver",
        "ActionBy", "Comments", "Remarks", "Vendor", "PONumber", "Link", "LinkButton", "ItemsTable", "PoItemsTable"
    ];

    private const string Items = "{{ItemsTable}}<p style=\"margin:8px 0\"><b>Total:</b> {{Total}}</p>";

    public static readonly List<TemplateDef> All =
    [
        new("request-pending-approval", "Approval needed", "Sent to the approver (and active delegates) when a request reaches them.",
            "Approval needed: {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Approval needed: {{RequestNo}}</h2>
            <p>Hello {{Recipient}},</p>
            <p><b>{{Requestor}}</b> ({{Department}}) submitted a stationery request. It is waiting for your decision as <b>{{Stage}}</b>.</p>
            """ + Items + """
            <p>Remarks: {{Remarks}}</p>
            {{LinkButton}}
            """),
        new("hrad-pending", "HR processing needed", "Sent to HRAD when all approvals are complete.",
            "Ready for HR processing: {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Ready for HR processing</h2>
            <p>Hello {{Recipient}},</p>
            <p>Request <b>{{RequestNo}}</b> from {{Requestor}} ({{Department}}) is fully approved. Please check the items, issue from store or order from a vendor.</p>
            """ + Items + """
            {{LinkButton}}
            """),
        new("request-approved", "Request approved", "Sent to the requestor after each approval step.",
            "{{RequestNo}} approved by {{ActionBy}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Your request moved forward</h2>
            <p>Hello {{Recipient}},</p>
            <p>Request <b>{{RequestNo}}</b> was approved by <b>{{ActionBy}}</b>. Status: <b>{{Status}}</b>. Waiting for: <b>{{Stage}} {{Approver}}</b>.</p>
            <p>Comments: {{Comments}}</p>
            {{LinkButton}}
            """),
        new("request-rejected", "Request rejected", "Sent to the requestor when a request is rejected.",
            "{{RequestNo}} was rejected",
            """
            <h2 style="margin:0 0 12px;font-size:18px;color:#b91c1c">Request rejected</h2>
            <p>Hello {{Recipient}},</p>
            <p>Request <b>{{RequestNo}}</b> was rejected by <b>{{ActionBy}}</b>.</p>
            <p><b>Reason:</b> {{Comments}}</p>
            {{LinkButton}}
            """),
        new("request-amend", "Amendment requested", "Sent to the requestor when an approver asks for changes.",
            "Changes requested: {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px;color:#c2410c">Please amend your request</h2>
            <p>Hello {{Recipient}},</p>
            <p><b>{{ActionBy}}</b> asked you to amend request <b>{{RequestNo}}</b> and submit it again.</p>
            <p><b>What to change:</b> {{Comments}}</p>
            {{LinkButton}}
            """),
        new("request-cancelled", "Request cancelled", "Sent to the current approver / HRAD when a request is withdrawn.",
            "{{RequestNo}} was cancelled",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Request cancelled</h2>
            <p>Hello {{Recipient}},</p>
            <p>Request <b>{{RequestNo}}</b> was cancelled by <b>{{ActionBy}}</b>. No action is needed from you.</p>
            <p><b>Reason:</b> {{Comments}}</p>
            """),
        new("po-vendor", "Purchase order to vendor", "Sent to the vendor with the purchase order PDF attached.",
            "Purchase Order {{PONumber}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Purchase order {{PONumber}}</h2>
            <p>Dear {{Recipient}},</p>
            <p>Please find the attached purchase order for <b>{{AppName}}</b> (reference {{RequestNo}}). Kindly confirm and deliver the items below.</p>
            {{PoItemsTable}}
            <p>Requested by: {{Requestor}}, {{Department}}. Deliver to: HR &amp; Admin.</p>
            """),
        new("po-vendor-revised", "Revised purchase order", "Sent to the vendor when the order is changed or re-ordered. The new PDF is attached.",
            "Revised Purchase Order {{PONumber}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Revised purchase order {{PONumber}}</h2>
            <p>Dear {{Recipient}},</p>
            <p>This replaces the earlier order for reference {{RequestNo}}. Please use the attached PDF and the quantities below.</p>
            {{PoItemsTable}}
            """),
        new("items-delivered", "Items ready - please verify", "Sent to the requestor when items are delivered or issued from store.",
            "Your items are ready: {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Your items are ready</h2>
            <p>Hello {{Recipient}},</p>
            <p>The items for request <b>{{RequestNo}}</b> are ready. Please open the request, check what you received and close it (or partially close it if something is missing).</p>
            """ + Items + """
            {{LinkButton}}
            """),
        new("request-edited-hr", "Line items changed by HR", "Sent to the requestor when HRAD edits the line items.",
            "Items updated by HR: {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Items were updated by HR</h2>
            <p>Hello {{Recipient}},</p>
            <p><b>{{ActionBy}}</b> changed the line items of request <b>{{RequestNo}}</b>.</p>
            <p><b>Reason:</b> {{Comments}}</p>
            """ + Items),
        new("request-closed", "Delivery verified", "Sent to HRAD when the requestor closes or partially closes a request.",
            "{{RequestNo}}: {{Status}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Delivery verified</h2>
            <p>Hello {{Recipient}},</p>
            <p>{{Requestor}} verified the delivery of <b>{{RequestNo}}</b>. Status: <b>{{Status}}</b>.</p>
            <p>Comments: {{Comments}}</p>
            {{LinkButton}}
            """),
        new("request-closed-shortfall", "Closed with shortfall", "Sent to the requestor when HRAD closes a partially received request.",
            "{{RequestNo}} closed with shortfall",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Request closed with shortfall</h2>
            <p>Hello {{Recipient}},</p>
            <p><b>{{ActionBy}}</b> closed request <b>{{RequestNo}}</b> although some items were not received.</p>
            <p><b>Comment:</b> {{Comments}}</p>
            """),
        new("requestor-query", "Query from requestor", "Sent to HRAD when the requestor raises a question.",
            "Query about {{RequestNo}}",
            """
            <h2 style="margin:0 0 12px;font-size:18px">Query from {{Requestor}}</h2>
            <p>Hello {{Recipient}},</p>
            <p>About request <b>{{RequestNo}}</b>:</p>
            <blockquote style="margin:8px 0;padding:8px 14px;border-left:4px solid #0070c9;background:#e6f1fb">{{Comments}}</blockquote>
            {{LinkButton}}
            """),
        new("delegation-created", "You are a delegate approver", "Sent to the person who receives delegated approvals.",
            "You are a delegate approver",
            """
            <h2 style="margin:0 0 12px;font-size:18px">You are a delegate approver</h2>
            <p>Hello {{Recipient}},</p>
            <p><b>{{ActionBy}}</b> delegated approvals to you.</p>
            <p><b>Period / reason:</b> {{Comments}}</p>
            <p>While the delegation is active their pending requests appear under <i>Pending for me</i>, and your decisions are recorded as &ldquo;on behalf of&rdquo;.</p>
            {{LinkButton}}
            """))
    ];
}
