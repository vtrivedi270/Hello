using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class WorkflowService(AppDbContext db, EmailService mail)
{
    /// <summary>Next approval stage after <paramref name="after"/>, skipping empty levels and the requestor. HRAD when done.</summary>
    public async Task<(string Stage, int? ApproverId)> NextStageAsync(RequestHeader h, string? after)
    {
        var req = await db.Employees.FindAsync(h.RequestorId);
        var dept = await db.Departments.FindAsync(h.DepartmentId);
        var div = await db.Divisions.FindAsync(h.DivisionId);
        var chain = new List<(string Stage, int? Id)> {
            ("ReportingManager", req!.ReportingManagerId),
            ("DeptHead", dept!.DepartmentHeadId),
            ("DivHead", div!.DivisionHeadId) };
        int start = after == null ? 0 : chain.FindIndex(c => c.Stage == after) + 1;
        for (int i = start; i < chain.Count; i++)
        {
            var (stage, id) = chain[i];
            if (id != null && id != h.RequestorId && !chain.Take(i).Any(c => c.Id == id)) return (stage, id);
        }
        return ("HRAD", null);
    }

    private static void Move(RequestHeader h, string stage, int? approver)
    {
        h.CurrentStage = stage; h.CurrentApproverId = approver;
        h.Status = stage == "HRAD" ? "HRApproval" : "InReview";
    }

    public void AddHistory(RequestHeader h, string stage, string action, Employee actor, string? comments) =>
        db.ApprovalHistories.Add(new ApprovalHistory { RequestId = h.RequestId, Stage = stage, Action = action, ActorId = actor.EmployeeId, Comments = comments });

    public async Task SubmitAsync(RequestHeader h, Employee actor)
    {
        if (h.RequestorId != actor.EmployeeId) throw new UnauthorizedAccessException("Only the requestor can submit");
        if (h.Status is not ("Draft" or "AmendRequired")) throw new InvalidOperationException("Request cannot be submitted in its current status");
        await db.Entry(h).Collection(x => x.Items).LoadAsync();
        if (h.Items.Count == 0) throw new InvalidOperationException("Add at least one item");
        var again = h.Status == "AmendRequired";
        var (stage, id) = await NextStageAsync(h, null);
        h.SubmittedAt = DateTime.UtcNow;
        Move(h, stage, id);
        AddHistory(h, "Requestor", again ? "Resubmit" : "Submit", actor, null);
        await db.SaveChangesAsync();
        await NotifyAsync(h, "Pending your action");
    }

    /// <summary>If <paramref name="actor"/> may act for the current approver through an active delegation, returns that approver.</summary>
    public async Task<Employee?> DelegatorAsync(RequestHeader h, Employee actor)
    {
        if (h.CurrentApproverId == null || h.CurrentApproverId == actor.EmployeeId) return null;
        var today = DateTime.Today;
        var d = await db.Delegations.Include(x => x.FromEmployee).FirstOrDefaultAsync(x => x.FromEmployeeId == h.CurrentApproverId
            && x.ToEmployeeId == actor.EmployeeId && x.IsActive && x.StartDate <= today && x.EndDate >= today);
        return d?.FromEmployee;
    }

    public async Task ActAsync(RequestHeader h, Employee actor, ActionDto dto)
    {
        if (h.RequestorId == actor.EmployeeId) throw new InvalidOperationException("You cannot approve your own request");
        var delegator = h.Status == "InReview" ? await DelegatorAsync(h, actor) : null;
        if (h.Status != "InReview" || (h.CurrentApproverId != actor.EmployeeId && delegator == null)) throw new UnauthorizedAccessException("This request is not pending with you");
        if (dto.Action != "Approve" && string.IsNullOrWhiteSpace(dto.Comments)) throw new InvalidOperationException("Comment is mandatory for Reject / Amend");
        var stage = h.CurrentStage!;
        switch (dto.Action)
        {
            case "Approve": var (next, id) = await NextStageAsync(h, stage); Move(h, next, id); break;
            case "Reject": h.Status = "Rejected"; h.CurrentStage = null; h.CurrentApproverId = null; h.ClosedAt = DateTime.UtcNow; break;
            case "Amend": h.Status = "AmendRequired"; h.CurrentStage = "Requestor"; h.CurrentApproverId = h.RequestorId; break;
            default: throw new InvalidOperationException("Invalid action");
        }
        AddHistory(h, stage, dto.Action, actor, delegator != null ? $"[On behalf of {delegator.FullName}] {dto.Comments}".Trim() : dto.Comments);
        await db.SaveChangesAsync();
        await NotifyAsync(h, dto.Action == "Approve" ? "Approved at " + stage : dto.Action, true, dto.Comments, actor.FullName);
    }

    /// <summary>Sends the template mails for a workflow event: the next approver / HRAD get "action needed", the requestor gets the outcome.</summary>
    public async Task NotifyAsync(RequestHeader h, string subject, bool toRequestor = false, string? comments = null, string? actionBy = null)
    {
        var extra = new Dictionary<string, string> { ["Comments"] = comments ?? "-", ["ActionBy"] = actionBy ?? "" };
        var actionRecipients = new List<string>();
        string actionKey = "request-pending-approval";
        if (h.Status == "InReview" && h.CurrentApproverId != null)
        {
            var a = await db.Employees.FindAsync(h.CurrentApproverId); if (a != null) actionRecipients.Add(a.Email);
            var today = DateTime.Today;
            actionRecipients.AddRange(await db.Delegations.Where(d => d.FromEmployeeId == h.CurrentApproverId && d.IsActive && d.StartDate <= today && d.EndDate >= today)
                .Select(d => d.ToEmployee!.Email).ToListAsync());
        }
        if (h.Status == "HRApproval")
        { actionKey = "hrad-pending"; actionRecipients.AddRange(await db.Employees.Where(e => e.Role == "HRAD" && e.IsActive).Select(e => e.Email).ToListAsync()); }
        foreach (var e in actionRecipients.Distinct())
            await mail.QueueRequestMailAsync(h.RequestId, e, actionKey, extra, $"[Stationery] {h.RequestNo}: {subject}", $"Request {h.RequestNo} - {subject}. Current status: {h.Status}.");

        if (!toRequestor) return;
        var key = subject.StartsWith("Approved") ? "request-approved" : subject == "Reject" ? "request-rejected" : subject == "Amend" ? "request-amend"
            : subject.StartsWith("Items") && subject.Contains("updated") || subject.StartsWith("Line items") ? "request-edited-hr"
            : subject.StartsWith("Items") ? "items-delivered" : subject.StartsWith("Closed") ? "request-closed-shortfall" : "request-approved";
        var r = await db.Employees.FindAsync(h.RequestorId);
        if (r != null) await mail.QueueRequestMailAsync(h.RequestId, r.Email, key, extra, $"[Stationery] {h.RequestNo}: {subject}", $"Request {h.RequestNo} - {subject}. Current status: {h.Status}.");
    }
}
