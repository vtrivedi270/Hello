using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using QuestPDF.Infrastructure;
using StationeryApi.Data;
using StationeryApi.Middleware;
using StationeryApi.Services;

QuestPDF.Settings.License = LicenseType.Community;
var b = WebApplication.CreateBuilder(args);
var jwt = b.Configuration.GetSection("Jwt");
if ((jwt["Key"] ?? "").Length < 32) throw new InvalidOperationException("Jwt:Key must be at least 32 characters");

b.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(b.Configuration.GetConnectionString("Default")));

// Scheme "Bearer" = application JWT with role claims (used by every API call).
var auth = b.Services.AddAuthentication("Bearer");
auth.AddJwtBearer("Bearer", o =>
{
    o.MapInboundClaims = false;
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidIssuer = jwt["Issuer"],
        ValidateAudience = true, ValidAudience = jwt["Audience"],
        ValidateIssuerSigningKey = true, IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!)),
        ValidateLifetime = true, ClockSkew = TimeSpan.FromMinutes(1),
        RoleClaimType = "role", NameClaimType = "name"
    };
});
// Scheme "Entra" = Azure AD access token, accepted only by POST /api/auth/login (token exchange).
if (b.Configuration.GetValue<bool>("Auth:EnableEntra"))
    auth.AddMicrosoftIdentityWebApi(b.Configuration, "AzureAd", "Entra");

b.Services.AddAuthorization();
b.Services.AddHttpContextAccessor();
b.Services.AddScoped<CurrentUser>();
b.Services.AddScoped<TokenService>();
b.Services.AddScoped<EmailService>();
b.Services.AddScoped<WorkflowService>();
b.Services.AddScoped<RequestService>();
b.Services.AddScoped<PdfService>();
b.Services.AddScoped<ImportService>();
b.Services.AddScoped<EmailTemplateService>();
b.Services.AddHostedService<EmailRetryWorker>();
b.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);
b.Services.AddCors(o => o.AddPolicy("spfx", p => p
    .WithOrigins(b.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? Array.Empty<string>())
    .AllowAnyHeader().AllowAnyMethod().WithExposedHeaders("Content-Disposition")));
b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(c =>
{
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    { Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT", In = ParameterLocation.Header,
      Description = "Call POST /api/auth/dev-login, then paste the returned token here." });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {{
        new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, Array.Empty<string>() }});
});

var app = b.Build();
using (var scope = app.Services.CreateScope())
{
    try { await scope.ServiceProvider.GetRequiredService<EmailTemplateService>().EnsureSeedAsync(); }   // adds missing default e-mail templates
    catch (Exception ex) { app.Logger.LogWarning(ex, "E-mail templates could not be seeded. Run Database/Upgrade_003_existing_db.sql if the table is missing."); }
}
app.UseMiddleware<ExceptionMiddleware>();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseHttpsRedirection();
app.UseCors("spfx");
app.UseAuthentication();
app.UseAuthorization();
app.MapGet("/health", () => Results.Ok(new { ok = true }));
app.MapControllers();
app.Run();
