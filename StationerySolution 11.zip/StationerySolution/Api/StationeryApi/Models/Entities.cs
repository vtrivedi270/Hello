using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace StationeryApi.Models;

public interface IActive { bool IsActive { get; set; } }

[Table("DivisionMaster")]
public class Division : IActive {
    [Key] public int DivisionId { get; set; }
    public string DivisionName { get; set; } = "";
    public int? DivisionHeadId { get; set; }
    public bool IsActive { get; set; } = true;
}
[Table("DepartmentMaster")]
public class Department : IActive {
    [Key] public int DepartmentId { get; set; }
    public string DepartmentName { get; set; } = "";
    public int DivisionId { get; set; }
    public int? DepartmentHeadId { get; set; }
    public bool IsActive { get; set; } = true;
}
[Table("EmployeeMaster")]
public class Employee : IActive {
    [Key] public int EmployeeId { get; set; }
    public string EmployeeCode { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public int DepartmentId { get; set; }
    public int DivisionId { get; set; }
    public int? ReportingManagerId { get; set; }
    public string Role { get; set; } = "Requestor";
    public bool IsActive { get; set; } = true;
    public Department? Department { get; set; }
    public Division? Division { get; set; }
    public Employee? ReportingManager { get; set; }
}
[Table("ItemCategoryMaster")]
public class ItemCategory : IActive {
    [Key] public int CategoryId { get; set; }
    public string CategoryName { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
[Table("ItemMaster")]
public class Item : IActive {
    [Key] public int ItemId { get; set; }
    public string ItemCode { get; set; } = "";
    public string ItemName { get; set; } = "";
    public int? CategoryId { get; set; }
    public string Unit { get; set; } = "";
    public decimal Rate { get; set; }
    public decimal StockQty { get; set; }
    public decimal ReorderLevel { get; set; }
    public bool IsActive { get; set; } = true;
}
[Table("VendorMaster")]
public class Vendor : IActive {
    [Key] public int VendorId { get; set; }
    public string VendorName { get; set; } = "";
    public string? ContactPerson { get; set; }
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? GSTNo { get; set; }
    public bool IsActive { get; set; } = true;
}
[Table("RequestHeader")]
public class RequestHeader {
    [Key] public int RequestId { get; set; }
    public string RequestNo { get; set; } = "";
    public DateTime RequestDate { get; set; } = DateTime.Today;
    public int RequestorId { get; set; }
    public int DepartmentId { get; set; }
    public int DivisionId { get; set; }
    public string? Remarks { get; set; }
    public decimal TotalAmount { get; set; }
    public string Status { get; set; } = "Draft";
    public string? CurrentStage { get; set; }
    public int? CurrentApproverId { get; set; }
    public int? VendorId { get; set; }
    public string? PONumber { get; set; }
    public DateTime? PODate { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public Employee Requestor { get; set; } = null!;
    public Employee? CurrentApprover { get; set; }
    public Vendor? Vendor { get; set; }
    public Department? Department { get; set; }
    public List<RequestItem> Items { get; set; } = new();
    public List<ApprovalHistory> History { get; set; } = new();
}
[Table("RequestItem")]
public class RequestItem {
    [Key] public int RequestItemId { get; set; }
    public int RequestId { get; set; }
    public int ItemId { get; set; }
    public string Unit { get; set; } = "";
    public decimal Rate { get; set; }
    public decimal Quantity { get; set; }
    public decimal? ApprovedQty { get; set; }
    public decimal IssuedFromStockQty { get; set; }
    public decimal OrderedQty { get; set; }
    public decimal ReceivedQty { get; set; }
    [DatabaseGenerated(DatabaseGeneratedOption.Computed)] public decimal LineTotal { get; set; }
    public string? Remarks { get; set; }
    public RequestHeader Request { get; set; } = null!;
    public Item Item { get; set; } = null!;
}
[Table("ApprovalHistory")]
public class ApprovalHistory {
    [Key] public long HistoryId { get; set; }
    public int RequestId { get; set; }
    public string Stage { get; set; } = "";
    public string Action { get; set; } = "";
    public int ActorId { get; set; }
    public string? Comments { get; set; }
    public DateTime ActionDate { get; set; } = DateTime.UtcNow;
    public Employee Actor { get; set; } = null!;
}
[Table("StockTransaction")]
public class StockTransaction {
    [Key] public long StockTxnId { get; set; }
    public int ItemId { get; set; }
    public string TxnType { get; set; } = "";
    public decimal Quantity { get; set; }
    public int? RequestId { get; set; }
    public string? Note { get; set; }
    public DateTime TxnDate { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
}
[Table("EmailLog")]
public class EmailLog {
    [Key] public long EmailLogId { get; set; }
    public int? RequestId { get; set; }
    public string ToEmail { get; set; } = "";
    public string? CcEmail { get; set; }
    public string Subject { get; set; } = "";
    public string? Body { get; set; }
    public string Status { get; set; } = "Pending";
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; }
    public bool AttachPo { get; set; }
    public bool IsHtml { get; set; }
    public DateTime? LastAttemptAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? SentAt { get; set; }
}
[Table("EmailTemplate")]
public class EmailTemplate {
    [Key] public string TemplateKey { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string Subject { get; set; } = "";
    public string BodyHtml { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public string? ModifiedBy { get; set; }
    public DateTime ModifiedAt { get; set; } = DateTime.UtcNow;
}
[Table("ExceptionLog")]
public class ExceptionLog {
    [Key] public long ExceptionId { get; set; }
    public string? Source { get; set; }
    public string? Message { get; set; }
    public string? StackTrace { get; set; }
    public string? RequestPath { get; set; }
    public string? UserEmail { get; set; }
    public DateTime LogDate { get; set; } = DateTime.UtcNow;
}
[Table("AuditLog")]
public class AuditLog {
    [Key] public long AuditId { get; set; }
    public string EntityName { get; set; } = "";
    public string EntityId { get; set; } = "";
    public string Action { get; set; } = "";
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string? UserEmail { get; set; }
    public DateTime LogDate { get; set; } = DateTime.UtcNow;
}

[Table("ApproverDelegation")]
public class ApproverDelegation {
    [Key] public int DelegationId { get; set; }
    public int FromEmployeeId { get; set; }
    public int ToEmployeeId { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string? Reason { get; set; }
    public bool IsActive { get; set; } = true;
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public Employee? FromEmployee { get; set; }
    public Employee? ToEmployee { get; set; }
}
