using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

/// <summary>Approver delegation: while away, an approver (or Admin on their behalf) names a delegate who can act on pending approvals.</summary>
[Authorize, ApiController, Route("api/delegations")]
public class DelegationsController(AppDbContext db, CurrentUser user, EmailService mail) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(bool all = false)
    {
        var me = await user.GetAsync();
        var today = DateTime.Today;
        var q = db.Delegations.AsNoTracking();
        if (!(all && me.Role == "Admin")) q = q.Where(d => d.FromEmployeeId == me.EmployeeId || d.ToEmployeeId == me.EmployeeId);
        return Ok(await q.OrderByDescending(d => d.StartDate).Take(200).Select(d => new
        {
            d.DelegationId, d.FromEmployeeId, FromName = d.FromEmployee!.FullName, d.ToEmployeeId, ToName = d.ToEmployee!.FullName,
            d.StartDate, d.EndDate, d.Reason, d.IsActive,
            ActiveNow = d.IsActive && d.StartDate <= today && d.EndDate >= today,
            Mine = d.FromEmployeeId == me.EmployeeId
        }).ToListAsync());
    }

    [HttpPost]
    public async Task<IActionResult> Create(DelegationCreateDto dto)
    {
        var me = await user.GetAsync();
        var fromId = dto.FromEmployeeId ?? me.EmployeeId;
        if (fromId != me.EmployeeId && me.Role != "Admin") throw new UnauthorizedAccessException("Only Admin can delegate on behalf of someone else");
        if (!User.IsInRole("Approver") && me.Role != "Admin") throw new UnauthorizedAccessException("Only approvers can delegate");
        if (fromId == dto.ToEmployeeId) throw new InvalidOperationException("Choose a different person as delegate");
        if (dto.EndDate.Date < dto.StartDate.Date) throw new InvalidOperationException("End date cannot be before start date");
        if (dto.EndDate.Date < DateTime.Today) throw new InvalidOperationException("End date is in the past");
        var from = await db.Employees.FindAsync(fromId) ?? throw new InvalidOperationException("Approver not found");
        var to = await db.Employees.FirstOrDefaultAsync(e => e.EmployeeId == dto.ToEmployeeId && e.IsActive) ?? throw new InvalidOperationException("Delegate not found or inactive");
        var overlap = await db.Delegations.AnyAsync(d => d.FromEmployeeId == fromId && d.IsActive && d.StartDate <= dto.EndDate.Date && d.EndDate >= dto.StartDate.Date);
        if (overlap) throw new InvalidOperationException("An active delegation already exists for these dates");

        var d = new ApproverDelegation { FromEmployeeId = fromId, ToEmployeeId = dto.ToEmployeeId, StartDate = dto.StartDate.Date, EndDate = dto.EndDate.Date, Reason = dto.Reason, CreatedBy = me.Email };
        db.Delegations.Add(d);
        await db.SaveChangesAsync();
        db.Audit("ApproverDelegation", d.DelegationId.ToString(), "Create", null, $"{from.FullName} -> {to.FullName} {d.StartDate:yyyy-MM-dd}..{d.EndDate:yyyy-MM-dd}", me.Email);
        await db.SaveChangesAsync();
        await mail.QueueTemplateAsync(to.Email, "delegation-created", new() { ["ActionBy"] = from.FullName, ["Comments"] = $"{d.StartDate:dd MMM yyyy} to {d.EndDate:dd MMM yyyy}" + (string.IsNullOrWhiteSpace(dto.Reason) ? "" : " - " + dto.Reason) }, "[Stationery] You are a delegate approver", $"{from.FullName} delegated approvals to you from {d.StartDate:dd MMM yyyy} to {d.EndDate:dd MMM yyyy}. Reason: {dto.Reason}");
        return Ok(new { d.DelegationId });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Revoke(int id)
    {
        var me = await user.GetAsync();
        var d = await db.Delegations.FindAsync(id) ?? throw new InvalidOperationException("Delegation not found");
        if (d.FromEmployeeId != me.EmployeeId && me.Role != "Admin") throw new UnauthorizedAccessException();
        d.IsActive = false;
        db.Audit("ApproverDelegation", id.ToString(), "Revoke", null, null, me.Email);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
