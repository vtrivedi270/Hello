using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

public record TemplateSaveDto(string Subject, string BodyHtml, bool IsActive);
public record TemplatePreviewDto(string Subject, string BodyHtml);

/// <summary>Admin: view, edit, preview, test-send and reset the HTML e-mail templates.</summary>
[Authorize(Roles = "Admin"), ApiController, Route("api/email-templates")]
public class EmailTemplatesController(AppDbContext db, EmailTemplateService tpl, EmailService mail, CurrentUser user) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List() =>
        Ok(new { placeholders = EmailTemplateDefaults.Placeholders,
            rows = await db.EmailTemplates.AsNoTracking().OrderBy(t => t.Name).Select(t => new { t.TemplateKey, t.Name, t.Description, t.Subject, t.IsActive, t.ModifiedBy, t.ModifiedAt }).ToListAsync() });

    [HttpGet("{key}")]
    public async Task<IActionResult> Get(string key)
    {
        var t = await db.EmailTemplates.AsNoTracking().FirstOrDefaultAsync(x => x.TemplateKey == key);
        return t == null ? NotFound() : Ok(t);
    }

    [HttpPut("{key}")]
    public async Task<IActionResult> Save(string key, TemplateSaveDto dto)
    {
        var t = await db.EmailTemplates.FindAsync(key) ?? throw new InvalidOperationException("Template not found");
        var errs = EmailTemplateService.Validate(dto.Subject, dto.BodyHtml);
        if (errs.Count > 0) throw new InvalidOperationException(string.Join(". ", errs));
        t.Subject = dto.Subject.Trim(); t.BodyHtml = dto.BodyHtml.Trim(); t.IsActive = dto.IsActive; t.ModifiedBy = user.Email; t.ModifiedAt = DateTime.UtcNow;
        db.Audit("EmailTemplate", key, "Update", null, t.Subject, user.Email);
        await db.SaveChangesAsync();
        return Ok(t);
    }

    /// <summary>Renders the (unsaved) subject and body with sample data so Admin can check the layout. Show the HTML in a sandboxed iframe.</summary>
    [HttpPost("{key}/preview")]
    public IActionResult Preview(string key, TemplatePreviewDto dto)
    {
        var errs = EmailTemplateService.Validate(dto.Subject, dto.BodyHtml);
        if (errs.Count > 0) throw new InvalidOperationException(string.Join(". ", errs));
        var (plain, raw) = tpl.SampleModel();
        var (subject, html) = tpl.RenderText(dto.Subject, dto.BodyHtml, plain, raw);
        return Ok(new { subject, html });
    }

    /// <summary>Sends the saved template with sample data to the signed-in admin's own address.</summary>
    [HttpPost("{key}/test")]
    public async Task<IActionResult> Test(string key)
    {
        var t = await db.EmailTemplates.AsNoTracking().FirstOrDefaultAsync(x => x.TemplateKey == key) ?? throw new InvalidOperationException("Template not found");
        var (plain, raw) = tpl.SampleModel();
        var (subject, html) = tpl.RenderText(t.Subject, t.BodyHtml, plain, raw);
        await mail.QueueAsync(null, user.Email, "[TEST] " + subject, html, html: true);
        return Ok(new { sentTo = user.Email, smtpConfigured = mail.SmtpConfigured });
    }

    [HttpPost("{key}/reset")]
    public async Task<IActionResult> Reset(string key)
    {
        var d = EmailTemplateDefaults.All.FirstOrDefault(x => x.Key == key) ?? throw new InvalidOperationException("There is no default for this template");
        var t = await db.EmailTemplates.FindAsync(key) ?? throw new InvalidOperationException("Template not found");
        t.Name = d.Name; t.Description = d.Description; t.Subject = d.Subject; t.BodyHtml = d.Body.Trim(); t.IsActive = true; t.ModifiedBy = user.Email; t.ModifiedAt = DateTime.UtcNow;
        db.Audit("EmailTemplate", key, "Reset", null, null, user.Email);
        await db.SaveChangesAsync();
        return Ok(t);
    }
}
