import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, MessageBar, MessageBarType, Panel, PrimaryButton, SearchBox, Spinner, TextField } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { card, row, h1, h2, mut, th, td, fmtDate } from './ui';
import Pager from './Pager';

interface StockRow { itemId: number; itemCode: string; itemName: string; unit: string; stockQty: number; reorderLevel: number; isLow: boolean; isActive: boolean; }
interface Txn { txnDate: string; txnType: string; quantity: number; note?: string; createdBy?: string; requestNo?: string; }
type Mode = 'receipt' | 'adjust' | 'history';

const Stock: React.FC<{ api: ApiService }> = ({ api }) => {
  const [rows, setRows] = useState<StockRow[]>([]);
  const [q, setQ] = useState('');
  const [lowOnly, setLowOnly] = useState(false);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState<string>();
  const [ok, setOk] = useState<string>();
  const [sel, setSel] = useState<StockRow>();
  const [mode, setMode] = useState<Mode>();
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [hist, setHist] = useState<Txn[]>([]);

  const load = (): void => { setBusy(true); api.get<StockRow[]>('stock').then(setRows).catch((e: Error) => setErr(e.message)).then(() => setBusy(false)); };
  useEffect(load, []);

  const open = (r: StockRow, m: Mode): void => {
    setSel(r); setMode(m); setQty(m === 'adjust' ? String(r.stockQty) : ''); setNote(''); setErr(undefined);
    if (m === 'history') api.get<Txn[]>('stock/' + r.itemId + '/history').then(setHist).catch((e: Error) => setErr(e.message));
  };
  const save = async (): Promise<void> => {
    if (!sel) return;
    try {
      if (mode === 'receipt') await api.post('stock/receipt', { itemId: sel.itemId, quantity: Number(qty), note: note });
      else await api.post('stock/adjust', { itemId: sel.itemId, newQty: Number(qty), reason: note });
      setOk(mode === 'receipt' ? 'Stock added' : 'Stock adjusted'); setMode(undefined); load();
    } catch (e) { setErr((e as Error).message); }
  };

  const shownAll = rows.filter(r => (!lowOnly || r.isLow) && (!q || (r.itemName + r.itemCode).toLowerCase().indexOf(q.toLowerCase()) > -1));
  const shown = shownAll.slice((page - 1) * size, page * size);
  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}><h1 style={h1}>Store stock</h1>
      <div style={row(8)}><SearchBox placeholder="Search item" value={q} onChange={(_, v) => { setQ(v || ''); setPage(1); }} styles={{ root: { width: 220 } }} />
        <DefaultButton text={lowOnly ? 'Showing low stock' : 'Low stock only'} onClick={() => { setLowOnly(!lowOnly); setPage(1); }} /></div></div>
    {err && !mode && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    {ok && <MessageBar messageBarType={MessageBarType.success} onDismiss={() => setOk(undefined)}>{ok}</MessageBar>}
    <div style={card}>
      {busy ? <Spinner /> : (<div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr>{['Code', 'Item', 'In stock', 'Reorder level', 'Status', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
        <tbody>{shown.map(r => (<tr key={r.itemId} style={{ opacity: r.isActive ? 1 : 0.5 }}>
          <td style={td}>{r.itemCode}</td><td style={td}><b>{r.itemName}</b></td><td style={td}>{r.stockQty} {r.unit}</td><td style={td}>{r.reorderLevel}</td>
          <td style={td}><span style={{ background: r.isLow ? '#dc2626' : '#15803d', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 12 }}>{r.isLow ? 'Low' : 'OK'}</span></td>
          <td style={td}><div style={row(6)}><PrimaryButton text="Add stock" onClick={() => open(r, 'receipt')} />
            <DefaultButton text="Adjust" onClick={() => open(r, 'adjust')} /><DefaultButton text="History" onClick={() => open(r, 'history')} /></div></td></tr>))}
          {shown.length === 0 && <tr><td style={td} colSpan={6}>No items.</td></tr>}</tbody></table></div>)}
      <Pager page={page} total={shownAll.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>

    <Panel isOpen={!!mode} onDismiss={() => setMode(undefined)} headerText={sel ? sel.itemName : ''} isFooterAtBottom
      onRenderFooterContent={() => mode === 'history' ? <DefaultButton text="Close" onClick={() => setMode(undefined)} /> :
        (<div style={row(8)}><PrimaryButton text="Save" onClick={save} /><DefaultButton text="Cancel" onClick={() => setMode(undefined)} /></div>)}>
      {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
      {sel && mode !== 'history' && (<div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 8 }}>
        <div style={mut}>Current stock: <b>{sel.stockQty} {sel.unit}</b></div>
        <TextField label={mode === 'receipt' ? 'Quantity received' : 'New stock quantity'} type="number" required value={qty} onChange={(_, v) => setQty(v || '')} />
        <TextField label={mode === 'receipt' ? 'Note (supplier / bill no)' : 'Reason (required)'} required={mode === 'adjust'} multiline rows={2} value={note} onChange={(_, v) => setNote(v || '')} />
      </div>)}
      {sel && mode === 'history' && (<div style={{ marginTop: 8 }}><h2 style={h2}>Last 50 movements</h2>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}><thead><tr><th style={th}>Date</th><th style={th}>Type</th><th style={th}>Qty</th><th style={th}>Note / request</th></tr></thead>
          <tbody>{hist.map((t, i) => (<tr key={i}><td style={td}>{fmtDate(t.txnDate)}</td><td style={td}>{t.txnType}</td>
            <td style={{ ...td, color: t.quantity < 0 || t.txnType === 'Issue' ? '#dc2626' : '#15803d' }}>{t.txnType === 'Issue' ? '-' : t.quantity > 0 ? '+' : ''}{t.quantity}</td>
            <td style={td}>{t.requestNo || t.note || '-'}</td></tr>))}{hist.length === 0 && <tr><td style={td} colSpan={4}>No movements yet.</td></tr>}</tbody></table></div>)}
    </Panel>
  </>);
};
export default Stock;
