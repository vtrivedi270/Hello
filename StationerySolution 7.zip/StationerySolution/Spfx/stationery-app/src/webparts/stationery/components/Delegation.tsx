import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, PrimaryButton, Spinner, TextField, Toggle } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { Me } from '../models';
import { card, row, h1, h2, mut, th, td, fmtDate } from './ui';

interface Deleg {
  delegationId: number; fromEmployeeId: number; fromName: string; toEmployeeId: number; toName: string;
  startDate: string; endDate: string; reason?: string; isActive: boolean; activeNow: boolean; mine: boolean;
}
interface Emp { employeeId: number; fullName: string; }

const today = (): string => new Date().toISOString().slice(0, 10);

/** Approver delegation: while you are away, a delegate can approve / amend / reject on your behalf (recorded in history). */
const Delegation: React.FC<{ api: ApiService; me: Me }> = ({ api, me }) => {
  const isAdmin = me.roles.indexOf('Admin') > -1;
  const [rows, setRows] = useState<Deleg[]>([]);
  const [emps, setEmps] = useState<Emp[]>([]);
  const [all, setAll] = useState(false);
  const [from, setFrom] = useState<number>(me.employeeId);
  const [to, setTo] = useState<number>();
  const [start, setStart] = useState(today());
  const [end, setEnd] = useState(today());
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState<string>();
  const [ok, setOk] = useState<string>();

  const load = (): void => {
    setBusy(true);
    api.get<Deleg[]>('delegations' + (all ? '?all=true' : '')).then(setRows).catch((e: Error) => setErr(e.message)).then(() => setBusy(false));
  };
  useEffect(() => { api.get<Emp[]>('masters/employees?active=true').then(setEmps).catch(() => undefined); }, []);
  useEffect(load, [all]);

  const create = async (): Promise<void> => {
    setErr(undefined); setOk(undefined);
    if (!to) { setErr('Choose a delegate'); return; }
    if (end < start) { setErr('End date cannot be before start date'); return; }
    try {
      await api.post('delegations', { fromEmployeeId: from === me.employeeId ? null : from, toEmployeeId: to, startDate: start, endDate: end, reason: reason });
      setOk('Delegation created. The delegate has been notified.'); setReason(''); load();
    } catch (e) { setErr((e as Error).message); }
  };
  const revoke = async (d: Deleg): Promise<void> => {
    if (!window.confirm('Revoke delegation to ' + d.toName + '?')) return;
    try { await api.del('delegations/' + d.delegationId); setOk('Delegation revoked'); load(); } catch (e) { setErr((e as Error).message); }
  };

  const state = (d: Deleg): [string, string] =>
    !d.isActive ? ['Revoked', '#6b7280'] : d.activeNow ? ['Active now', '#15803d'] : d.startDate.slice(0, 10) > today() ? ['Scheduled', '#2563eb'] : ['Expired', '#b45309'];
  const people = emps.filter(e => e.employeeId !== from);

  return (<>
    <h1 style={h1}>Delegation</h1>
    {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    {ok && <MessageBar messageBarType={MessageBarType.success} onDismiss={() => setOk(undefined)}>{ok}</MessageBar>}
    <div style={card}>
      <h2 style={h2}>Delegate my approvals</h2>
      <div style={mut}>While the delegation is active, the delegate sees your pending approvals and can act on them. Their decision is recorded as "on behalf of {me.fullName}".</div>
      <div style={{ ...row(14), marginTop: 12, alignItems: 'flex-end' }}>
        {isAdmin && <Dropdown label="Approver (Admin)" styles={{ root: { width: 220 } }} selectedKey={from}
          options={emps.map(e => ({ key: e.employeeId, text: e.fullName }))} onChange={(_, o) => setFrom(Number(o!.key))} />}
        <Dropdown label="Delegate to" placeholder="Select person" required styles={{ root: { width: 240 } }} selectedKey={to}
          options={people.map(e => ({ key: e.employeeId, text: e.fullName }))} onChange={(_, o) => setTo(Number(o!.key))} />
        <TextField label="From" type="date" value={start} onChange={(_, v) => setStart(v || '')} />
        <TextField label="To" type="date" value={end} onChange={(_, v) => setEnd(v || '')} />
        <TextField label="Reason" value={reason} onChange={(_, v) => setReason(v || '')} styles={{ root: { width: 220 } }} />
        <PrimaryButton text="Create delegation" onClick={create} />
      </div>
    </div>
    <div style={card}>
      <div style={{ ...row(12), justifyContent: 'space-between' }}>
        <h2 style={{ ...h2, margin: 0 }}>{all ? 'All delegations' : 'My delegations'}</h2>
        {isAdmin && <Toggle label="Show all" inlineLabel checked={all} onChange={(_, c) => setAll(!!c)} />}
      </div>
      {busy ? <Spinner /> : (
        <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 8 }}>
          <thead><tr>{['Approver', 'Delegate', 'From', 'To', 'Reason', 'Status', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td style={td} colSpan={7}>No delegations.</td></tr>}
            {rows.map(d => { const s = state(d); return (
              <tr key={d.delegationId}>
                <td style={td}>{d.fromName}{d.mine ? ' (you)' : ''}</td><td style={td}>{d.toName}{d.toEmployeeId === me.employeeId ? ' (you)' : ''}</td>
                <td style={td}>{fmtDate(d.startDate)}</td><td style={td}>{fmtDate(d.endDate)}</td><td style={td}>{d.reason || '-'}</td>
                <td style={td}><span style={{ background: s[1], color: '#fff', borderRadius: 12, padding: '2px 10px', fontSize: 12 }}>{s[0]}</span></td>
                <td style={td}>{d.isActive && (d.mine || isAdmin) && <DefaultButton text="Revoke" onClick={() => revoke(d)} />}</td>
              </tr>); })}
          </tbody></table></div>)}
    </div>
  </>);
};
export default Delegation;
