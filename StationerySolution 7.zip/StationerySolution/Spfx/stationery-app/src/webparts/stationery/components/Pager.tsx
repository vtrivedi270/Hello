import * as React from 'react';
import { DefaultButton } from '@fluentui/react';
import { row } from './ui';

interface Props { page: number; total: number; pageSize: number; onPage: (p: number) => void; onSize?: (n: number) => void; }

/** Reusable pager: Prev / Next, page x of y, record count and optional rows-per-page selector. */
const Pager: React.FC<Props> = ({ page, total, pageSize, onPage, onSize }) => {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  return (
    <div style={{ ...row(10), marginTop: 12 }}>
      <DefaultButton text="Prev" disabled={page <= 1} onClick={() => onPage(page - 1)} />
      <span>Page {Math.min(page, pages)} of {pages} · {total} record(s)</span>
      <DefaultButton text="Next" disabled={page >= pages} onClick={() => onPage(page + 1)} />
      {onSize && (<label style={{ fontSize: 12, color: '#5b6275' }}>Rows{' '}
        <select value={pageSize} onChange={e => onSize(Number(e.target.value))} aria-label="Rows per page">
          {[10, 20, 50].map(n => <option key={n} value={n}>{n}</option>)}
        </select></label>)}
    </div>);
};
export default Pager;
