import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, Panel, PanelType, PrimaryButton, TextField } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { Item, RequestDetail, Vendor } from '../models';
import { card, h2, mut, row, th, td } from './ui';

interface Props { api: ApiService; r: RequestDetail; onChanged: (msg: string) => void; onError: (msg: string) => void; }
interface Line { itemId: number; itemName: string; quantity: number; minQty: number; fixed: boolean; }

/** HRAD tools: edit line items of any open request, resend PO, re-order a shortfall, close a shortfall. */
const HradTools: React.FC<Props> = ({ api, r, onChanged, onError }) => {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Item[]>([]);
  const [lines, setLines] = useState<Line[]>([]);
  const [reason, setReason] = useState('');
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [vendorId, setVendorId] = useState<number>();
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get<Item[]>('masters/items?active=true').then(setItems).catch(() => undefined);
    api.get<Vendor[]>('masters/vendors?active=true').then(setVendors).catch(() => undefined);
  }, []);

  const terminal = ['Closed', 'Rejected', 'Cancelled'].indexOf(r.status) > -1;
  const partial = r.status === 'PartialClosed';
  const post = r.status === 'Ordered' || r.status === 'Delivered';
  if (terminal) return null;

  const run = async (fn: () => Promise<any>, msg: string): Promise<void> => {
    setBusy(true);
    try { await fn(); onChanged(msg); setOpen(false); setComment(''); } catch (e) { onError((e as Error).message); }
    setBusy(false);
  };

  const startEdit = (): void => {
    setLines(r.items.map(i => ({ itemId: i.itemId, itemName: i.itemName, quantity: i.quantity,
      minQty: Math.max(i.issuedFromStockQty, i.receivedQty), fixed: i.issuedFromStockQty > 0 || i.receivedQty > 0 })));
    setReason(''); setOpen(true);
  };
  const upd = (idx: number, patch: Partial<Line>): void => setLines(lines.map((l, i) => i === idx ? { ...l, ...patch } : l));
  const pick = (idx: number, itemId: number): void => {
    if (lines.some((l, i) => i !== idx && l.itemId === itemId)) { onError('Item already in the request'); return; }
    const it = items.filter(x => x.itemId === itemId)[0];
    upd(idx, { itemId: itemId, itemName: it ? it.itemName : '' });
  };

  const save = (): void => {
    if (!reason.trim()) { onError('Reason is required'); return; }
    if (lines.some(l => !l.itemId || !(l.quantity > 0) || l.quantity < l.minQty)) { onError('Check items and quantities (cannot be below issued / received quantity)'); return; }
    run(() => api.put<any>('hrad/' + r.requestId + '/items', { reason: reason, items: lines.map(l => ({ itemId: l.itemId, quantity: l.quantity })) }),
      post ? 'Line items updated. Please resend the PO to the vendor.' : 'Line items updated');
  };

  const outstanding = r.items.map(i => ({ i: i, out: Math.max(0, (i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty) - i.receivedQty) })).filter(x => x.out > 0);

  return (
    <div style={card}>
      <h2 style={h2}>HRAD tools</h2>
      <div style={row(8)}>
        {!partial && <DefaultButton text="Edit line items" onClick={startEdit} />}
        {r.status === 'Ordered' && <DefaultButton text="Resend PO to vendor" disabled={busy} onClick={() => run(() => api.post('hrad/' + r.requestId + '/resend-po'), 'Revised PO sent')} />}
      </div>
      {post && <div style={{ ...mut, marginTop: 8 }}>The vendor order was already sent. After changing items, use Resend PO.</div>}

      {partial && (<div style={{ marginTop: 6 }}>
        <div style={{ ...mut, marginBottom: 8 }}>Partially received. Outstanding quantity:</div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr><th style={th}>Item</th><th style={th}>Expected</th><th style={th}>Received</th><th style={th}>Outstanding</th></tr></thead>
          <tbody>{outstanding.map(x => (<tr key={x.i.requestItemId}><td style={td}>{x.i.itemName}</td>
            <td style={td}>{x.i.approvedQty === null || x.i.approvedQty === undefined ? x.i.quantity : x.i.approvedQty}</td><td style={td}>{x.i.receivedQty}</td><td style={td}><b>{x.out}</b></td></tr>))}</tbody>
        </table>
        <div style={{ ...row(10), marginTop: 12 }}>
          <Dropdown placeholder="Vendor for re-order" styles={{ root: { width: 260 } }} selectedKey={vendorId}
            options={vendors.map(v => ({ key: v.vendorId, text: v.vendorName }))} onChange={(_, o) => setVendorId(Number(o!.key))} />
          <PrimaryButton text="Re-order shortfall" disabled={busy || !vendorId}
            onClick={() => run(() => api.post('hrad/' + r.requestId + '/reorder', { vendorId: vendorId, comments: comment }), 'Outstanding quantity re-ordered')} />
        </div>
        <TextField label="Comment (required to close with shortfall)" value={comment} onChange={(_, v) => setComment(v || '')} styles={{ root: { marginTop: 8 } }} />
        <DefaultButton text="Close with shortfall" disabled={busy || !comment.trim()} styles={{ root: { marginTop: 8 } }}
          onClick={() => run(() => api.post('hrad/' + r.requestId + '/close-short', { action: 'CloseShort', comments: comment }), 'Request closed')} />
      </div>)}

      <Panel isOpen={open} onDismiss={() => setOpen(false)} type={PanelType.large} headerText={'Edit line items - ' + r.requestNo} isFooterAtBottom
        onRenderFooterContent={() => (<div style={row(8)}><PrimaryButton text="Save changes" disabled={busy} onClick={save} /><DefaultButton text="Cancel" onClick={() => setOpen(false)} /></div>)}>
        {post && <MessageBar messageBarType={MessageBarType.warning}>The order was already sent to the vendor. Quantities will update the PO; resend it after saving.</MessageBar>}
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 10 }}>
          <thead><tr><th style={th}>Item</th><th style={th}>Qty</th><th style={th} /></tr></thead>
          <tbody>{lines.map((l, i) => (
            <tr key={i}>
              <td style={{ ...td, minWidth: 220 }}>{l.itemId && r.items.some(x => x.itemId === l.itemId)
                ? l.itemName
                : <Dropdown placeholder="Select item" selectedKey={l.itemId || undefined} options={items.map(x => ({ key: x.itemId, text: x.itemCode + ' - ' + x.itemName }))} onChange={(_, o) => pick(i, Number(o!.key))} />}</td>
              <td style={{ ...td, width: 110 }}><TextField type="number" value={String(l.quantity)} onChange={(_, v) => upd(i, { quantity: Math.max(0, Number(v) || 0) })} /></td>
              <td style={td}><DefaultButton text="Remove" disabled={l.fixed} title={l.fixed ? 'Already issued / received' : ''} onClick={() => setLines(lines.filter((_, x) => x !== i))} /></td>
            </tr>))}</tbody>
        </table>
        <DefaultButton text="+ Add item" styles={{ root: { marginTop: 10 } }} onClick={() => setLines([...lines, { itemId: 0, itemName: '', quantity: 1, minQty: 0, fixed: false }])} />
        <TextField label="Reason for change (required)" multiline rows={2} value={reason} onChange={(_, v) => setReason(v || '')} styles={{ root: { marginTop: 14 } }} />
      </Panel>
    </div>);
};
export default HradTools;
