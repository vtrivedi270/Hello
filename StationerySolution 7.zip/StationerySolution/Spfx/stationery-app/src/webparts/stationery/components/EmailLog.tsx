import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { card, row, h1, th, td } from './ui';

interface Mail { emailLogId: number; requestId?: number; toEmail: string; subject: string; status: string; errorMessage?: string; retryCount: number; createdAt: string; sentAt?: string; }
const COLOR: { [k: string]: string } = { Sent: '#15803d', Pending: '#b45309', Failed: '#dc2626' };
const PAGE = 25;

/** Admin: e-mail log. Failed / pending mails are retried automatically by the API; you can also retry one manually. */
const EmailLog: React.FC<{ api: ApiService }> = ({ api }) => {
  const [rows, setRows] = useState<Mail[]>([]);
  const [total, setTotal] = useState(0);
  const [smtp, setSmtp] = useState(true);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState<string>();
  const [ok, setOk] = useState<string>();

  const load = (): void => {
    setBusy(true);
    api.get<{ total: number; rows: Mail[]; smtpConfigured: boolean }>('emails?page=' + page + '&pageSize=' + PAGE + (status ? '&status=' + status : ''))
      .then(r => { setRows(r.rows); setTotal(r.total); setSmtp(r.smtpConfigured); }).catch((e: Error) => setErr(e.message)).then(() => setBusy(false));
  };
  useEffect(load, [status, page]);

  const retry = async (m: Mail): Promise<void> => {
    setErr(undefined); setOk(undefined);
    try { const r = await api.post<{ status: string; errorMessage?: string }>('emails/' + m.emailLogId + '/retry'); r.status === 'Sent' ? setOk('Mail sent') : setErr(r.errorMessage || 'Still failing'); load(); }
    catch (e) { setErr((e as Error).message); }
  };

  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}>
      <h1 style={h1}>E-mail log</h1>
      <Dropdown selectedKey={status} styles={{ root: { width: 170 } }} onChange={(_, o) => { setStatus(String(o!.key)); setPage(1); }}
        options={[{ key: '', text: 'All' }, { key: 'Pending', text: 'Pending' }, { key: 'Failed', text: 'Failed' }, { key: 'Sent', text: 'Sent' }]} />
    </div>
    {!smtp && <MessageBar messageBarType={MessageBarType.warning}>SMTP is not configured (Smtp:Host is empty). Mails stay Pending until it is set; the retry job then sends them.</MessageBar>}
    {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    {ok && <MessageBar messageBarType={MessageBarType.success} onDismiss={() => setOk(undefined)}>{ok}</MessageBar>}
    <div style={card}>
      {busy ? <Spinner /> : (<div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr>{['Created', 'To', 'Subject', 'Status', 'Tries', 'Error', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td style={td} colSpan={7}>No mails.</td></tr>}
          {rows.map(m => (<tr key={m.emailLogId}>
            <td style={td}>{new Date(m.createdAt).toLocaleString('en-GB')}</td><td style={td}>{m.toEmail}</td>
            <td style={{ ...td, maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.subject}</td>
            <td style={td}><span style={{ background: COLOR[m.status] || '#6b7280', color: '#fff', borderRadius: 12, padding: '2px 10px', fontSize: 12 }}>{m.status}</span></td>
            <td style={td}>{m.retryCount}</td><td style={{ ...td, maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis' }} title={m.errorMessage}>{m.errorMessage || '-'}</td>
            <td style={td}>{m.status !== 'Sent' && <DefaultButton text="Retry" onClick={() => retry(m)} />}</td></tr>))}
        </tbody></table></div>)}
      <div style={{ ...row(10), marginTop: 12 }}>
        <DefaultButton text="Prev" disabled={page === 1} onClick={() => setPage(page - 1)} />
        <span>Page {page} of {Math.max(1, Math.ceil(total / PAGE))}</span>
        <DefaultButton text="Next" disabled={page * PAGE >= total} onClick={() => setPage(page + 1)} />
      </div>
    </div>
  </>);
};
export default EmailLog;
