import * as React from 'react';
import { useEffect, useState } from 'react';
import { MessageBar, MessageBarType, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { Me, Route, RouteName } from '../models';
import { C } from './ui';
import SideNav from './SideNav';
import Dashboard from './Dashboard';
import RequestList from './RequestList';
import RequestForm from './RequestForm';
import RequestDetailView from './RequestDetailView';
import Admin from './Admin';
import Stock from './Stock';
import Delegation from './Delegation';
import EmailLog from './EmailLog';

interface Props { api: ApiService; }

const App: React.FC<Props> = ({ api }) => {
  const [me, setMe] = useState<Me>();
  const [err, setErr] = useState<string>();
  const [route, setRoute] = useState<Route>({ name: 'dash' });
  const [pending, setPending] = useState(0);
  const [collapsed, setCollapsed] = useState(typeof window !== 'undefined' && window.innerWidth < 900);

  const refreshPending = (): void => {
    api.get<{ total: number }>('requests?view=pending&page=1&pageSize=1').then(r => setPending(r.total)).catch(() => undefined);
  };

  useEffect(() => { api.get<Me>('me').then(setMe).catch((e: Error) => setErr(e.message)); }, []);
  useEffect(() => { if (me) refreshPending(); }, [me, route.name, route.id]);

  const go = (name: RouteName, id?: number): void => { setRoute({ name: name, id: id }); };

  if (err) return <MessageBar messageBarType={MessageBarType.error}>Cannot load your profile: {err}</MessageBar>;
  if (!me) return <Spinner label="Loading Stationery Hub..." />;

  const active: RouteName = route.name === 'detail' || route.name === 'edit' ? 'list' : route.name;
  let view: React.ReactNode;
  switch (route.name) {
    case 'list': view = <RequestList api={api} me={me} go={go} />; break;
    case 'new': view = <RequestForm api={api} me={me} go={go} />; break;
    case 'edit': view = <RequestForm api={api} me={me} go={go} requestId={route.id} />; break;
    case 'detail': view = <RequestDetailView api={api} me={me} go={go} requestId={route.id!} />; break;
    case 'stock': view = me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1 ? <Stock api={api} /> : <MessageBar messageBarType={MessageBarType.blocked}>HRAD or Admin access required</MessageBar>; break;
    case 'delegation': view = <Delegation api={api} me={me} />; break;
    case 'emails': view = me.roles.indexOf('Admin') > -1 ? <EmailLog api={api} /> : <MessageBar messageBarType={MessageBarType.blocked}>Admin access required</MessageBar>; break;
    case 'admin': view = me.roles.indexOf('Admin') > -1 ? <Admin api={api} /> : <MessageBar messageBarType={MessageBarType.blocked}>Admin access required</MessageBar>; break;
    default: view = <Dashboard api={api} me={me} go={go} />;
  }

  return (
    <div style={{ display: 'flex', minHeight: 640, background: C.bg, fontFamily: '"Segoe UI",system-ui,sans-serif', color: C.ink }}>
      <SideNav me={me} active={active} pending={pending} collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} go={go} />
      <main style={{ flex: 1, minWidth: 0, padding: 24, display: 'flex', flexDirection: 'column', gap: 18 }}>{view}</main>
    </div>
  );
};
export default App;
