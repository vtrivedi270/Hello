import * as React from 'react';
import { Me, RouteName } from '../models';

interface Props {
  me: Me;
  active: RouteName;
  pending: number;
  collapsed: boolean;
  onToggle: () => void;
  go: (n: RouteName) => void;
}

const ICONS: { [k: string]: string } = {
  dash: 'M3 3h7v9H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 16h7v5H3z',
  list: 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2M5.5 5h13l3.5 7v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6z',
  add: 'M12 5v14M5 12h14',
  admin: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19 12l2-1.5-2-3.4-2.3.9-2-1.2L14 3h-4l-.4 2.8-2 1.2-2.3-.9-2 3.4L5 12l-2 1.5 2 3.4 2.3-.9 2 1.2L10 21h4l.4-2.8 2-1.2 2.3.9 2-3.4z',
  users: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
  mail: 'M4 4h16v16H4zM4 6l8 7 8-7',
  box: 'M21 8l-9-5-9 5v8l9 5 9-5zM3 8l9 5 9-5M12 13v8',
  menu: 'M4 6h16M4 12h16M4 18h16'
};
const Svg = ({ k }: { k: string }) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flex: 'none' }}>
    <path d={ICONS[k]} />
  </svg>);

interface NavItem { key: RouteName; label: string; icon: string; badge?: number; }

const SideNav: React.FC<Props> = ({ me, active, pending, collapsed, onToggle, go }) => {
  const main: NavItem[] = [
    { key: 'dash', label: 'Dashboard', icon: 'dash' },
    { key: 'list', label: 'Requests', icon: 'list', badge: pending }
  ];
  const work: NavItem[] = [{ key: 'new', label: 'New request', icon: 'add' }];
  if (me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1) work.push({ key: 'stock', label: 'Store stock', icon: 'box' });
  if (me.roles.indexOf('Approver') > -1 || me.roles.indexOf('Admin') > -1) work.push({ key: 'delegation', label: 'Delegation', icon: 'users' });
  const admin: NavItem[] = me.roles.indexOf('Admin') > -1
    ? [{ key: 'admin', label: 'Admin masters', icon: 'admin' }, { key: 'emails', label: 'E-mail log', icon: 'mail' }] : [];
  const w = collapsed ? 64 : 232;
  const initials = me.fullName.split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase();

  const Section = ({ title, items }: { title: string; items: NavItem[] }) => items.length === 0 ? null : (
    <div style={{ marginTop: 14 }}>
      {!collapsed && <div style={{ fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: '#818cf8', padding: '0 12px 6px' }}>{title}</div>}
      {items.map(n => {
        const on = active === n.key;
        return (
          <button key={n.key} onClick={() => go(n.key)} title={collapsed ? n.label : undefined} aria-current={on ? 'page' : undefined}
            style={{ position: 'relative', width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', margin: '2px 0', minHeight: 44,
              border: 0, borderRadius: 10, cursor: 'pointer', fontSize: 14, textAlign: 'left', justifyContent: collapsed ? 'center' : 'flex-start',
              background: on ? 'linear-gradient(90deg,#4338ca,#6366f1)' : 'transparent', color: on ? '#fff' : '#c7d2fe',
              boxShadow: on ? '0 4px 12px rgba(67,56,202,.45)' : 'none' }}>
            <Svg k={n.icon} />
            {!collapsed && <span style={{ flex: 1 }}>{n.label}</span>}
            {n.badge ? (
              <span style={{ background: '#f59e0b', color: '#1f2433', borderRadius: 10, fontSize: 11, fontWeight: 700, minWidth: 20, padding: '1px 6px', textAlign: 'center',
                ...(collapsed ? { position: 'absolute', top: 4, right: 6 } : {}) }}>{n.badge}</span>) : null}
          </button>);
      })}
    </div>);

  return (
    <nav aria-label="Main navigation" style={{ width: w, flex: 'none', transition: 'width .2s', background: 'linear-gradient(180deg,#1e1b4b,#0f0d2e)',
      padding: '14px 10px', display: 'flex', flexDirection: 'column', boxSizing: 'border-box', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 6px 16px', justifyContent: collapsed ? 'center' : 'space-between' }}>
        {!collapsed && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: '#fff', fontWeight: 700, fontSize: 16 }}>
            <div style={{ width: 32, height: 32, borderRadius: 9, background: 'linear-gradient(135deg,#6366f1,#a855f7)', display: 'grid', placeItems: 'center' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 20l4-1 11-11-3-3L5 16zM14 6l3 3" /></svg>
            </div>Stationery Hub
          </div>)}
        <button onClick={onToggle} aria-label={collapsed ? 'Expand menu' : 'Collapse menu'} aria-expanded={!collapsed}
          style={{ border: 0, background: 'rgba(255,255,255,.08)', color: '#c7d2fe', borderRadius: 8, width: 34, height: 34, cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
          <Svg k="menu" />
        </button>
      </div>

      <Section title="Overview" items={main} />
      <Section title="Work" items={work} />
      <Section title="Administration" items={admin} />

      <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 10, padding: 10, borderRadius: 12, background: 'rgba(255,255,255,.07)', justifyContent: collapsed ? 'center' : 'flex-start' }}>
        <div title={me.fullName} style={{ width: 36, height: 36, borderRadius: '50%', background: '#6366f1', color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 700, flex: 'none' }}>{initials}</div>
        {!collapsed && (
          <div style={{ minWidth: 0 }}>
            <div style={{ color: '#fff', fontWeight: 600, fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{me.fullName}</div>
            <div style={{ color: '#a5b4fc', fontSize: 11, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{me.roles.join(' / ')} · {me.departmentName}</div>
          </div>)}
      </div>
    </nav>);
};
export default SideNav;
