import * as React from 'react';
import { useState } from 'react';
import { ChoiceGroup, DefaultButton, MessageBar, MessageBarType, Panel, PanelType, Pivot, PivotItem, PrimaryButton, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { ImportReport, LineOut } from '../models';
import { fmt, mut, row, th, td, csvCell, downloadText } from './ui';
import Pager from './Pager';

interface Props { api: ApiService; isOpen: boolean; onDismiss: () => void; onApply: (lines: LineOut[], mode: 'replace' | 'add') => void; }

/** Requestor: import line items from Excel into the entry form. The file is validated on the server; nothing is saved until the request is saved. */
const LineImportPanel: React.FC<Props> = ({ api, isOpen, onDismiss, onApply }) => {
  const [report, setReport] = useState<ImportReport>();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [mode, setMode] = useState<'replace' | 'add'>('replace');
  const [view, setView] = useState('lines');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);

  const reset = (): void => { setReport(undefined); setErr(undefined); setPage(1); setView('lines'); };
  const close = (): void => { reset(); onDismiss(); };

  const pick = async (f?: File): Promise<void> => {
    reset();
    if (!f) return;
    if (!/\.xlsx$/i.test(f.name)) { setErr('Only .xlsx files are supported (found "' + f.name + '").'); return; }
    if (f.size > 5 * 1024 * 1024) { setErr('The file is larger than 5 MB.'); return; }
    setBusy(true);
    try {
      const fd = new FormData(); fd.append('file', f);
      const r = await api.postForm<ImportReport>('requests/import-lines', fd);
      setReport(r); setView(r.errors.length ? 'errors' : 'lines');
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  const errorReport = (): void => {
    if (!report) return;
    downloadText('request-lines-import-errors.csv', ['Row,Column,Value,Problem'].concat(report.errors.map(e => [e.row || '', e.column, e.value, e.message].map(csvCell).join(','))).join('\r\n'));
  };

  const ne = report ? report.errors.length : 0;
  const lines = report && report.lines ? report.lines : [];
  const list: any[] = view === 'errors' ? (report ? report.errors : []) : lines;
  const shown = list.slice((page - 1) * size, page * size);
  const chip = (bg: string, t: string): JSX.Element => <span style={{ background: bg, color: '#fff', borderRadius: 20, padding: '2px 10px', fontSize: 12 }}>{t}</span>;

  return (
    <Panel isOpen={isOpen} onDismiss={close} type={PanelType.large} headerText="Import line items from Excel" isFooterAtBottom
      onRenderFooterContent={() => (<div style={row(8)}>
        <PrimaryButton text={'Apply ' + lines.length + ' line(s)'} disabled={busy || !report || ne > 0 || lines.length === 0} onClick={() => { onApply(lines, mode); close(); }} />
        {ne > 0 && <DefaultButton text="Download error report (CSV)" onClick={errorReport} />}
        <DefaultButton text="Close" onClick={close} />
      </div>)}>
      <MessageBar messageBarType={MessageBarType.info}>Columns: <b>ItemCode</b> (required, an active item), <b>Quantity</b> (required, 0.01 to 100000, max 2 decimals), Remarks (optional, max 200). The template lists all item codes. No duplicate items, up to 200 lines, header in row 1, max 5 MB.</MessageBar>
      <div style={{ ...row(8), margin: '12px 0' }}>
        <DefaultButton text="Download template" onClick={() => api.download('requests/lines-template', 'request-lines-template.xlsx').catch((e: Error) => setErr(e.message))} />
      </div>
      <input type="file" accept=".xlsx" aria-label="Excel file" onChange={e => { pick(e.target.files ? e.target.files[0] : undefined); e.target.value = ''; }} />
      {busy && <Spinner label="Checking the file..." />}
      {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)} styles={{ root: { marginTop: 10 } }}>{err}</MessageBar>}
      {report && (<>
        <div style={{ ...row(8), margin: '12px 0' }}>{chip('#6b7280', report.fileName)}{chip('#2563eb', 'Rows ' + report.total)}{chip('#15803d', 'Valid ' + lines.length)}{chip(ne ? '#dc2626' : '#15803d', 'Errors ' + ne)}</div>
        <Pivot selectedKey={view} onLinkClick={i => { setView(i!.props.itemKey!); setPage(1); }}>
          <PivotItem headerText={'Errors (' + ne + ')'} itemKey="errors" />
          <PivotItem headerText={'Valid lines (' + lines.length + ')'} itemKey="lines" />
        </Pivot>
        <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
          {view === 'errors' ? (<><thead><tr><th style={th}>Row</th><th style={th}>Column</th><th style={th}>Value</th><th style={th}>Problem</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td style={td} colSpan={4}>No errors.</td></tr>}
              {shown.map((e, i) => <tr key={i}><td style={td}>{e.row || '–'}</td><td style={td}>{e.column}</td><td style={td}>{e.value}</td><td style={{ ...td, whiteSpace: 'normal' }}>{e.message}</td></tr>)}</tbody></>)
          : (<><thead><tr><th style={th}>Row</th><th style={th}>Item</th><th style={th}>Qty</th><th style={th}>Rate</th><th style={th}>Total</th><th style={th}>Remarks</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td style={td} colSpan={6}>No valid lines.</td></tr>}
              {shown.map((l: LineOut, i) => <tr key={i}><td style={td}>{l.row}</td><td style={td}>{l.itemCode} – {l.itemName}</td><td style={td}>{l.quantity} {l.unit}</td>
                <td style={td}>{fmt(l.rate)}</td><td style={td}>{fmt(l.rate * l.quantity)}</td><td style={td}>{l.remarks || ''}</td></tr>)}</tbody></>)}
        </table></div>
        <Pager page={page} total={list.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
        <ChoiceGroup label="How should these lines be applied?" selectedKey={mode} styles={{ root: { marginTop: 12 } }}
          options={[{ key: 'replace', text: 'Replace the current lines' }, { key: 'add', text: 'Add to the current lines (quantities of the same item are added)' }]}
          onChange={(_, o) => setMode(o!.key as 'replace' | 'add')} />
        {ne > 0 && <MessageBar messageBarType={MessageBarType.warning} styles={{ root: { marginTop: 10 } }}>Nothing can be applied until all {ne} error(s) are fixed. Correct your Excel file and upload it again.</MessageBar>}
        <div style={{ ...mut, marginTop: 8 }}>Nothing is saved until you click Save as draft or Submit on the request.</div>
      </>)}
    </Panel>);
};
export default LineImportPanel;
