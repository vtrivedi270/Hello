import * as React from 'react';
import { useState } from 'react';
import { DefaultButton, MessageBar, MessageBarType, Panel, PanelType, Pivot, PivotItem, PrimaryButton, Spinner } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { ImportReport } from '../models';
import { row, th, td, mut, csvCell, downloadText } from './ui';
import Pager from './Pager';

const SPECS: { [k: string]: { title: string; req: string[]; opt: string[]; rules: string } } = {
  items: { title: 'Items', req: ['ItemCode', 'ItemName', 'Unit', 'Rate'], opt: ['Category', 'StockQty', 'ReorderLevel', 'Active'],
    rules: 'ItemCode unique (max 30) · Rate 0 or more, max 2 decimals · Category must already exist · StockQty is used for new items only (existing stock changes via Store stock)' },
  categories: { title: 'Categories', req: ['CategoryName'], opt: ['Active'], rules: 'CategoryName unique (max 100) · Active = Y or N' },
  vendors: { title: 'Vendors', req: ['VendorName', 'Email'], opt: ['ContactPerson', 'Phone', 'Address', 'GSTNo', 'Active'], rules: 'Valid e-mail · GSTNo = 15 letters / digits · VendorName unique' },
  divisions: { title: 'Divisions', req: ['DivisionName'], opt: ['DivisionHead', 'Active'], rules: 'DivisionName unique · DivisionHead = code, e-mail or name of an existing employee' },
  departments: { title: 'Departments', req: ['DepartmentName', 'Division'], opt: ['DepartmentHead', 'Active'], rules: 'Division must already exist · name + division unique · DepartmentHead = code, e-mail or name of an existing employee' },
  employees: { title: 'Employees', req: ['EmployeeCode', 'FullName', 'Email', 'Department', 'Role'], opt: ['ReportingManager', 'Active'],
    rules: 'Code and e-mail unique · Department must exist · Role = Requestor, HRAD, Admin, ReportingManager, DeptHead or DivHead · ReportingManager = employee code or e-mail (existing or in this file), no loops, blank keeps the current manager' }
};

interface Props { api: ApiService; entity: string; isOpen: boolean; onDismiss: () => void; onImported: (msg: string) => void; }

/** Admin: import master data from Excel. Choose file -> automatic validation (nothing saved) -> fix errors or import. All-or-nothing. */
const ExcelImportPanel: React.FC<Props> = ({ api, entity, isOpen, onDismiss, onImported }) => {
  const spec = SPECS[entity];
  const [file, setFile] = useState<File>();
  const [report, setReport] = useState<ImportReport>();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string>();
  const [view, setView] = useState('errors');
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  if (!spec) return null;

  const reset = (): void => { setFile(undefined); setReport(undefined); setErr(undefined); setPage(1); setView('errors'); };
  const close = (): void => { reset(); onDismiss(); };
  const form = (f: File): FormData => { const fd = new FormData(); fd.append('file', f); return fd; };

  const pick = async (f?: File): Promise<void> => {
    reset();
    if (!f) return;
    if (!/\.xlsx$/i.test(f.name)) { setErr('Only .xlsx files are supported (found "' + f.name + '").'); return; }
    if (f.size > 5 * 1024 * 1024) { setErr('The file is larger than 5 MB.'); return; }
    setFile(f); setBusy(true);
    try {
      const r = await api.postForm<ImportReport>('import/' + entity + '/validate', form(f));
      setReport(r); setView(r.errors.length ? 'errors' : 'preview');
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  const commit = async (): Promise<void> => {
    if (!file) return;
    setBusy(true); setErr(undefined);
    try {
      const r = await api.postForm<ImportReport>('import/' + entity + '/commit', form(file));
      if (r.applied) { onImported(r.message); close(); return; }
      setReport(r); setView('errors'); setErr(r.message);
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  const errorReport = (): void => {
    if (!report) return;
    downloadText(entity + '-import-errors.csv', ['Row,Column,Value,Problem'].concat(report.errors.map(e => [e.row || '', e.column, e.value, e.message].map(csvCell).join(','))).join('\r\n'));
  };

  const download = (kind: string): void => { api.download('import/' + entity + '/' + kind, entity + '-' + kind + '.xlsx').catch((e: Error) => setErr(e.message)); };

  const ne = report ? report.errors.length : 0;
  const nv = report ? report.plan.length : 0;
  const list: any[] = !report ? [] : view === 'errors' ? report.errors : view === 'preview' ? report.plan : report.warnings;
  const shown = list.slice((page - 1) * size, page * size);
  const chip = (bg: string, t: string): JSX.Element => <span style={{ background: bg, color: '#fff', borderRadius: 20, padding: '2px 10px', fontSize: 12 }}>{t}</span>;

  return (
    <Panel isOpen={isOpen} onDismiss={close} type={PanelType.large} headerText={'Import ' + spec.title.toLowerCase() + ' from Excel'} isFooterAtBottom
      onRenderFooterContent={() => (<div style={row(8)}>
        <PrimaryButton text={'Import ' + nv + ' row(s)'} disabled={busy || !report || ne > 0 || nv === 0} onClick={commit} />
        {ne > 0 && <DefaultButton text="Download error report (CSV)" onClick={errorReport} />}
        <DefaultButton text="Close" onClick={close} />
      </div>)}>
      <MessageBar messageBarType={MessageBarType.info}>1 Download the template · 2 Fill it in · 3 Upload (it is checked automatically) · 4 Import. Nothing is saved until you click Import, and one error blocks the whole import.</MessageBar>
      <div style={{ ...row(8), margin: '12px 0' }}>
        <DefaultButton text="Download template" onClick={() => download('template')} />
        <DefaultButton text="Export current data" onClick={() => download('export')} />
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr><th style={th}>Required columns</th><th style={th}>Optional columns</th></tr></thead>
        <tbody><tr><td style={td}>{spec.req.join(', ')}</td><td style={td}>{spec.opt.join(', ')}</td></tr>
          <tr><td style={{ ...td, whiteSpace: 'normal', ...mut }} colSpan={2}>{spec.rules}. Header in row 1 of the first sheet, up to 1000 rows, max 5 MB.</td></tr></tbody>
      </table>
      <div style={{ margin: '14px 0' }}>
        <input type="file" accept=".xlsx" aria-label="Excel file" onChange={e => { pick(e.target.files ? e.target.files[0] : undefined); e.target.value = ''; }} />
      </div>
      {busy && <Spinner label="Checking the file..." />}
      {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
      {report && (<>
        <div style={{ ...row(8), margin: '8px 0' }}>
          {chip('#6b7280', report.fileName)}{chip('#2563eb', 'Rows ' + report.total)}{chip('#15803d', 'Valid ' + nv)}
          {chip(ne ? '#dc2626' : '#15803d', 'Errors ' + ne)}{report.warnings.length > 0 && chip('#b45309', 'Warnings ' + report.warnings.length)}
        </div>
        <Pivot selectedKey={view} onLinkClick={i => { setView(i!.props.itemKey!); setPage(1); }}>
          <PivotItem headerText={'Errors (' + ne + ')'} itemKey="errors" />
          <PivotItem headerText={'Rows to import (' + nv + ')'} itemKey="preview" />
          {report.warnings.length > 0 && <PivotItem headerText={'Warnings (' + report.warnings.length + ')'} itemKey="warnings" />}
        </Pivot>
        <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
          {view === 'errors' && (<><thead><tr><th style={th}>Row</th><th style={th}>Column</th><th style={th}>Value</th><th style={th}>Problem</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td style={td} colSpan={4}>No errors.</td></tr>}
              {shown.map((e, i) => <tr key={i}><td style={td}>{e.row || '–'}</td><td style={td}>{e.column}</td><td style={td}>{e.value}</td><td style={{ ...td, whiteSpace: 'normal' }}>{e.message}</td></tr>)}</tbody></>)}
          {view === 'preview' && (<><thead><tr><th style={th}>Row</th><th style={th}>Action</th><th style={th}>Key</th><th style={th}>Name</th><th style={th}>Info</th></tr></thead>
            <tbody>{shown.length === 0 && <tr><td style={td} colSpan={5}>No valid rows.</td></tr>}
              {shown.map((p, i) => <tr key={i}><td style={td}>{p.row}</td><td style={td}><span style={{ background: p.update ? '#2563eb' : '#15803d', color: '#fff', borderRadius: 12, padding: '2px 8px', fontSize: 12 }}>{p.update ? 'Update' : 'Create'}</span></td>
                <td style={td}>{p.show[0]}</td><td style={td}>{p.show[1]}</td><td style={td}>{p.show[2]}</td></tr>)}</tbody></>)}
          {view === 'warnings' && <tbody>{shown.map((w, i) => <tr key={i}><td style={{ ...td, whiteSpace: 'normal' }}>{w}</td></tr>)}</tbody>}
        </table></div>
        <Pager page={page} total={list.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
        {ne > 0 && <MessageBar messageBarType={MessageBarType.warning} styles={{ root: { marginTop: 10 } }}>Import is blocked until all {ne} error(s) are fixed. Correct your Excel file and upload it again.</MessageBar>}
      </>)}
    </Panel>);
};
export default ExcelImportPanel;
